export type CurrencyCode = 'XOF' | 'XAF' | 'USD' | 'EUR' | 'JPY' | 'NGN' | 'GHS' | 'GBP' | 'CAD';

export interface PlanConfig {
  id: string;
  name: string;
  priceXOF: number;
  durationMonths: number;
  durationLabel: string;
  maxVideoDuration: string;
  hasWatermark: boolean;
  resolution: 'HD' | '4K' | '4K Ultra';
  features: string[];
  popular?: boolean;
  highlightColor: string;
  badge?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  countryCode: string;
  planId: string; // 'free' | plan id
  planExpiresAt?: string;
  credits: number;
  isAdmin: boolean;
  isVip: boolean;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  planId: string;
  planName: string;
  amountXOF: number;
  currency: CurrencyCode;
  amountLocal: number;
  paymentMethod: 'WAVE' | 'ORANGE_MONEY' | 'MTN_MOMO' | 'MOOV' | 'CARD' | 'USDT';
  continent: string;
  country: string;
  city: string;
  status: 'COMPLETED' | 'PENDING';
  timestamp: string;
  reference: string;
}

export interface AdminSettings {
  registrationFeeXOF: number;
  plans: PlanConfig[];
  mobileMoneyAccounts: {
    wave: string;
    orangeMoney: string;
    mtnMoMo: string;
    moov: string;
  };
  cryptoAccounts: {
    usdtTrc20: string;
    usdtErc20: string;
  };
  bankAccount: {
    bankName: string;
    iban: string;
    bic: string;
  };
  cityAdjustments: { [cityOrCountry: string]: number }; // percentage discount or surge
  systemAnnouncements: string[];
}

export interface StudioStyle {
  id: string;
  name: string;
  description: string;
  tag: string;
  color: string;
}

export interface WorldStudio {
  id: string;
  name: string;
  country: string;
  specialty: string;
  signatureStyle: string;
  color: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'collaborator' | 'algorithm';
  senderName: string;
  avatar?: string;
  text: string;
  timestamp: string;
  role?: string;
}

export interface CharacterItem {
  id: string;
  name: string;
  role: string;
  photoUrl: string;
  personality: string;
  voiceStyle: string;
  outfit: string;
  hair: string;
  eyes: string;
}

export interface LandscapeItem {
  id: string;
  title: string;
  timeOfDay: 'Jour' | 'Nuit' | 'Crépuscule' | 'Aurore';
  weather: 'Pluie Néon' | 'Ciel Étoilé' | 'Brume Mystique' | 'Pétales de Cerisier' | 'Tempête Électrique';
  lighting: 'Néon Violet/Cyan' | 'Doré Cinématographique' | 'Sombre Profond' | 'Aquarelle Douce';
  imageUrl: string;
}
