import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ChatMessage } from '../types';
import { 
  Send, 
  MessageSquare, 
  Paperclip, 
  Users, 
  Smile, 
  CheckCheck, 
  Sparkles,
  X
} from 'lucide-react';

interface CollaborativeChatProps {
  isOpen: boolean;
  onClose: () => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'm1',
    sender: 'collaborator',
    senderName: 'Sora (Directeur Artistique)',
    avatar: '🎨',
    text: "Salut l'équipe ! J'ai ajusté la colorimétrie de la scène 3 en néon violet et cyan. Le rendu 4K est magnifique.",
    timestamp: '14:20',
  },
  {
    id: 'm2',
    sender: 'collaborator',
    senderName: 'Kenji (Scénariste Tokyo)',
    avatar: '✍️',
    text: "Super ! J'ai ajouté un dialogue dramatique juste avant le combat au sabre : 'Le vent n'oublie jamais le serment du guerrier.'",
    timestamp: '14:22',
  },
  {
    id: 'm3',
    sender: 'assistant',
    senderName: 'Kamui Copilote IA',
    avatar: '⚡',
    text: "Suggestion d'animation : synchronisation labiale calibrée sur 60 FPS avec travelling avant lors de la réplique de Kenji.",
    timestamp: '14:23',
  },
];

export const CollaborativeChat: React.FC<CollaborativeChatProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      senderName: user?.name || 'Moi (Créateur)',
      avatar: '🎬',
      text: inputText.trim(),
      timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Simulated reply from co-director
    setTimeout(() => {
      const autoReply: ChatMessage = {
        id: `msg-reply-${Date.now()}`,
        sender: 'collaborator',
        senderName: 'Aoi (Animatrice)',
        avatar: '✨',
        text: "Bien reçu ! Je lance la génération des mouvements intermédiaires sur ce plan.",
        timestamp: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, autoReply]);
    }, 1200);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-[#0b0f20] border-l border-purple-500/30 shadow-2xl flex flex-col">
      
      {/* Chat Header - WhatsApp style */}
      <div className="p-4 bg-[#0e142a] border-b border-purple-900/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-amber-400 p-[1.5px]">
            <div className="w-full h-full bg-[#0b0f20] rounded-full flex items-center justify-center text-amber-300">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>Studio Collaboratif</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </h4>
            <p className="text-[11px] text-slate-400">
              3 membres en ligne • Co-production en direct
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[radial-gradient(#1e1b4b15_1px,transparent_1px)] [background-size:16px_16px]">
        {messages.map((msg) => {
          const isMe = msg.sender === 'user';
          const isAI = msg.sender === 'assistant';

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 mb-1 px-1">
                <span className="text-xs">{msg.avatar}</span>
                <span className="text-[10px] font-semibold text-slate-400">
                  {msg.senderName}
                </span>
              </div>
              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                  isMe
                    ? 'bg-purple-600 text-white rounded-tr-none'
                    : isAI
                    ? 'bg-amber-950/60 border border-amber-500/40 text-amber-200 rounded-tl-none'
                    : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700/60'
                }`}
              >
                {msg.text}
                <div
                  className={`text-[9px] mt-1.5 flex items-center justify-end gap-1 ${
                    isMe ? 'text-purple-200' : 'text-slate-400'
                  }`}
                >
                  <span>{msg.timestamp}</span>
                  {isMe && <CheckCheck className="w-3 h-3 text-amber-300" />}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Field Form */}
      <form onSubmit={handleSendMessage} className="p-3 bg-[#0e142a] border-t border-purple-900/40 flex items-center gap-2">
        <button
          type="button"
          onClick={() => alert("Ajout de script ou storyboard joint au salon.")}
          className="p-2 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-white/5"
          title="Joindre un fichier de script"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        <input
          type="text"
          placeholder="Écrire à l'équipe de production..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="flex-1 py-2 px-3.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-purple-500"
        />

        <button
          type="submit"
          className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-900/50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
};
