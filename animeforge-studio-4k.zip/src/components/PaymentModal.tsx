import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { PlanConfig, CurrencyCode } from '../types';
import { convertFromXOF } from '../services/currency';
import confetti from 'canvas-confetti';
import { 
  X, 
  CheckCircle2, 
  Smartphone, 
  CreditCard as CardIcon, 
  Coins, 
  ShieldCheck, 
  ArrowRight,
  Zap,
  Lock,
  Copy,
  Check
} from 'lucide-react';

interface PaymentModalProps {
  plan: PlanConfig;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ plan, isOpen, onClose, onSuccess }) => {
  const { selectedCurrency, processSubscription, adminSettings, user } = useAuth();
  
  const [method, setMethod] = useState<'WAVE' | 'ORANGE_MONEY' | 'MTN_MOMO' | 'MOOV' | 'CARD' | 'USDT'>('WAVE');
  const [phoneNumber, setPhoneNumber] = useState(user?.phone || '');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDone, setIsDone] = useState(false);

  if (!isOpen) return null;

  const { formatted, amount: localAmount } = convertFromXOF(plan.priceXOF, selectedCurrency);

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      // Simulate real-time automated webhook validation
      await new Promise((resolve) => setTimeout(resolve, 1400));
      
      await processSubscription(plan.id, method, {
        phone: phoneNumber,
        cardLast4: cardNumber ? cardNumber.slice(-4) : undefined,
        txHash: method === 'USDT' ? '0x' + Math.random().toString(16).slice(2, 10) : undefined,
      });

      setIsProcessing(false);
      setIsDone(true);

      // Trigger Confetti Celebration
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#a855f7', '#f59e0b', '#06b6d4', '#10b981'],
      });

      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1800);
    } catch (err) {
      setIsProcessing(false);
      alert("Erreur lors de l'encaissement.");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#090d1c] border border-purple-500/40 p-6 sm:p-8 shadow-2xl shadow-purple-950/80">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          disabled={isProcessing}
          className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!isDone ? (
          <>
            {/* Header */}
            <div className="mb-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
                <Zap className="w-3.5 h-3.5" />
                <span>Validation Automatique Immédiate • 0 Attente</span>
              </div>
              <h3 className="text-2xl font-black text-white font-cinzel">
                Paiement Sécurisé : {plan.name}
              </h3>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-extrabold text-amber-400 font-cinzel">
                  {formatted}
                </span>
                <span className="text-xs text-slate-400">
                  / {plan.durationLabel}
                </span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="mb-5">
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Sélectionnez votre moyen de paiement sécurisé :
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setMethod('WAVE')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'WAVE'
                      ? 'bg-cyan-950/70 border-cyan-400 text-cyan-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>Wave Money</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('ORANGE_MONEY')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'ORANGE_MONEY'
                      ? 'bg-orange-950/70 border-orange-500 text-orange-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-orange-400" />
                  <span>Orange Money</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('MTN_MOMO')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'MTN_MOMO'
                      ? 'bg-yellow-950/70 border-yellow-500 text-yellow-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-yellow-400" />
                  <span>MTN MoMo</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('MOOV')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'MOOV'
                      ? 'bg-blue-950/70 border-blue-500 text-blue-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-blue-400" />
                  <span>Moov Africa</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('CARD')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'CARD'
                      ? 'bg-purple-950/70 border-purple-500 text-purple-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <CardIcon className="w-4 h-4 text-purple-400" />
                  <span>Carte Visa/Master</span>
                </button>

                <button
                  type="button"
                  onClick={() => setMethod('USDT')}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${
                    method === 'USDT'
                      ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300 shadow-sm'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Coins className="w-4 h-4 text-emerald-400" />
                  <span>Crypto USDT</span>
                </button>
              </div>
            </div>

            {/* Payment Details Form */}
            <form onSubmit={handlePay} className="space-y-4">
              
              {/* Mobile Money Details */}
              {(method === 'WAVE' || method === 'ORANGE_MONEY' || method === 'MTN_MOMO' || method === 'MOOV') && (
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Numéro destinataire configuré :</span>
                    <span className="font-mono-code font-bold text-amber-300">
                      {method === 'WAVE' && adminSettings.mobileMoneyAccounts.wave}
                      {method === 'ORANGE_MONEY' && adminSettings.mobileMoneyAccounts.orangeMoney}
                      {method === 'MTN_MOMO' && adminSettings.mobileMoneyAccounts.mtnMoMo}
                      {method === 'MOOV' && adminSettings.mobileMoneyAccounts.moov}
                    </span>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Votre Numéro Mobile Money pour validation du débit :
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+225 07 00 00 00 00"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-cyan-400 text-sm text-white focus:outline-none"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400">
                    💡 Dès que vous cliquez sur "Valider", une notification de confirmation apparaîtra sur votre téléphone. L'accès VIP est débloqué instantanément.
                  </p>
                </div>
              )}

              {/* Credit Card Details */}
              {method === 'CARD' && (
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Numéro de carte Visa / Mastercard
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="4000 1234 5678 9010"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      maxLength={19}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-400 text-sm text-white focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Expiration
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="MM/AA"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        maxLength={5}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-400 text-sm text-white focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        CVC / CVV
                      </label>
                      <input
                        type="password"
                        required
                        placeholder="123"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        maxLength={4}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-purple-400 text-sm text-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* USDT Crypto Details */}
              {method === 'USDT' && (
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                  <div className="text-xs">
                    <span className="text-slate-400 block mb-1">Adresse de réception USDT (TRC-20) officielle :</span>
                    <div className="flex items-center gap-2 p-2 rounded-xl bg-black border border-slate-800">
                      <span className="font-mono-code text-[11px] text-emerald-400 truncate">
                        {adminSettings.cryptoAccounts.usdtTrc20}
                      </span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(adminSettings.cryptoAccounts.usdtTrc20)}
                        className="p-1 rounded bg-slate-800 text-slate-300 hover:text-white shrink-0"
                      >
                        {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Réseau TRC-20 (Tron) ou ERC-20. Détection automatique du hash de transaction par notre algorithme.
                  </p>
                </div>
              )}

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-4 rounded-xl text-sm font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>Vérification algorithmique du paiement en cours...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Payer {formatted} et Débloquer l'Accès VIP Immédiat</span>
                  </>
                )}
              </button>

              <div className="text-center">
                <p className="text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
                  <Lock className="w-3 h-3 text-emerald-400" />
                  <span>Protégé par le système anti-piratage • Transaction cryptée sans frais cachés</span>
                </p>
              </div>
            </form>
          </>
        ) : (
          /* Success Screen */
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-white font-cinzel">
              Paiement Validé avec Succès !
            </h3>
            <p className="text-sm text-slate-300 max-w-sm mx-auto">
              Votre formule <strong className="text-amber-400">{plan.name}</strong> ({plan.durationLabel}) est désormais active.
            </p>
            <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-500/30 text-xs text-purple-200">
              ✨ Le filigrane "Kamui Studio" a été retiré. Rendu 4K 60fps débloqué !
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
