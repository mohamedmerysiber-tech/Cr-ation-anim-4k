import React from 'react';
import { X, ShieldCheck, CheckCircle2, Lock, Award, FileText } from 'lucide-react';

interface RightsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RightsModal: React.FC<RightsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#090d1c] border border-emerald-500/40 p-6 sm:p-8 shadow-2xl shadow-emerald-950/60 max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mb-3">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-cinzel">
            Charte Officielle de Propriété Intellectuelle (100% Vos Droits)
          </h2>
          <p className="text-xs text-emerald-300 font-semibold mt-1">
            Kamui Studio 4K / AnimeForge • Protection Juridique Internationale
          </p>
        </div>

        {/* Content Clauses */}
        <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Article 1 : Propriété Exclusive Totale</span>
            </h4>
            <p>
              Chaque créateur, scénariste ou réalisateur utilisant la plateforme Kamui Studio conserve <strong>100 % des droits patrimoniaux et moraux</strong> sur l'intégralité de ses œuvres : scénarios, dialogues, voix enregistrées ou synthétisées, personnages créés, univers visuels et films d'animation exportés.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Article 2 : Exploitation Commerciale Libre & Sans Redevance</span>
            </h4>
            <p>
              Vous êtes libre de monétiser, diffuser sur YouTube, TikTok, Netflix, Crunchyroll, le cinéma ou la télévision, ou vendre vos créations sans verser la moindre redevance (0 % de royalties réclamées par la plateforme).
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-purple-400" />
              <span>Article 3 : Confidentialité & Sécurité Anti-Piratage</span>
            </h4>
            <p>
              Vos imports (visages, croquis, voix) sont chiffrés et ne sont jamais revendus ni utilisés pour entraîner des modèles publics sans votre consentement écrit. Vos modes privés de création restent strictement sous votre contrôle.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Certificat de conformité WIPO / OMPI et convention de Berne sur le droit d'auteur.</span>
          </div>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={onClose}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-extrabold text-xs hover:brightness-110 shadow-md"
          >
            J'ai Compris & J'Accepte
          </button>
        </div>

      </div>
    </div>
  );
};
