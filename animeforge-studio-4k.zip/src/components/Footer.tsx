import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Film, 
  ShieldCheck, 
  Lock, 
  Globe, 
  Sparkles, 
  Heart,
  Crown
} from 'lucide-react';

interface FooterProps {
  onOpenRightsModal: () => void;
  onOpenAuth: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenRightsModal, onOpenAuth }) => {
  const { setActiveView, user } = useAuth();

  return (
    <footer className="border-t border-purple-900/30 bg-[#05070f] text-slate-400 text-xs">
      {/* 100% Rights Prominent Ribbon */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-purple-950/40 to-slate-950 border-b border-emerald-500/20 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-white font-bold text-xs sm:text-sm">
              Garantie Fondamentale : Chaque créateur conserve 100 % des droits de propriété sur ses œuvres.
            </span>
          </div>
          <button
            onClick={onOpenRightsModal}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-semibold text-xs transition-colors shrink-0"
          >
            Consulter la Charte Juridique
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1 : Brand & Slogan */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-700 to-amber-400 p-[1px] flex items-center justify-center">
                <div className="w-full h-full bg-[#05070f] rounded-[7px] flex items-center justify-center">
                  <Film className="w-4 h-4 text-amber-400" />
                </div>
              </div>
              <span className="text-lg font-black text-white font-cinzel">
                KAMUI STUDIO
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              "Votre imagination en 4K. Créez des animés complets de A à Z, sans limite."
            </p>
            <p className="text-[11px] text-slate-500">
              AnimeForge Studio 4K • Plateforme mondiale de création d'animation assistée par IA.
            </p>
          </div>

          {/* Col 2 : Studio Features */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-cinzel">
              Moteur Studio
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>
                <button onClick={() => setActiveView('studio')} className="hover:text-amber-400 transition-colors">
                  Mode Privé (Retouche Scènes)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('studio')} className="hover:text-purple-400 transition-colors">
                  Assistant & Encyclopédie Mondiale
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('studio')} className="hover:text-cyan-400 transition-colors">
                  12 Styles & 15 Grands Studios
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('studio')} className="hover:text-emerald-400 transition-colors">
                  Casting 100k Photos & Clonage Vidéo
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('studio')} className="hover:text-rose-400 transition-colors">
                  Clonage Vocal & Studio Musique
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3 : Abonnements & Paiements */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-cinzel">
              Abonnements & Sécurité
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>
                <button onClick={() => setActiveView('catalog')} className="hover:text-amber-400 transition-colors">
                  Catalogue des 8 Packs Officiels
                </button>
              </li>
              <li>
                <span className="text-slate-300">Wave, Orange, MTN, Moov</span>
              </li>
              <li>
                <span className="text-slate-300">Cartes Bancaires Visa / Mastercard</span>
              </li>
              <li>
                <span className="text-slate-300">Crypto USDT (TRC-20 / ERC-20)</span>
              </li>
              <li className="text-[11px] text-emerald-400 flex items-center gap-1 pt-1">
                <Lock className="w-3 h-3" />
                <span>Paiements Chiffrés SHA-256</span>
              </li>
            </ul>
          </div>

          {/* Col 4 : International & Droits */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-cinzel">
              Couverture Mondiale
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Compatible avec tous les pays (Zone FCFA, Europe, Amérique du Nord, Asie, Afrique). Détection géographique et conversion automatique multi-devises en temps réel.
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-300/80">
              <Globe className="w-3.5 h-3.5" />
              <span>Abidjan • Dakar • Paris • Tokyo • New York</span>
            </div>
          </div>

        </div>

        {/* Bottom Credits & Copyright */}
        <div className="mt-8 pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <div>
            © 2026 Kamui Studio 4K / AnimeForge Studio. Tous droits réservés.
          </div>
          <div className="flex items-center gap-4">
            <button onClick={onOpenRightsModal} className="hover:text-white transition-colors">
              Propriété Intellectuelle (100%)
            </button>
            <span>•</span>
            <span className="text-slate-400">Sécurité Anti-Piratage Active</span>
            <span>•</span>
            <button onClick={() => setActiveView('catalog')} className="hover:text-white transition-colors">
              Tarifs
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
