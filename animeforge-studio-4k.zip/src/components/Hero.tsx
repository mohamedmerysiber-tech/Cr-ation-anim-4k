import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Play, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  Camera, 
  MessageSquare, 
  ArrowRight, 
  CheckCircle2, 
  Layers, 
  Zap,
  Volume2,
  VolumeX,
  Tv
} from 'lucide-react';

interface HeroProps {
  onStartFreeTrial: () => void;
  onExplorePlans: () => void;
  onOpenRightsModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  onStartFreeTrial, 
  onExplorePlans,
  onOpenRightsModal 
}) => {
  const { setActiveView } = useAuth();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [activePreviewStyle, setActivePreviewStyle] = useState<'shonen' | 'kyoto' | 'cyber'>('shonen');

  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
      {/* Background Cinematic Atmosphere */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] pointer-events-none overflow-hidden opacity-40">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/30 rounded-full blur-[128px] animate-pulse-glow" />
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-amber-500/20 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 left-1/3 w-80 h-80 bg-cyan-500/20 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Floating Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-950/70 border border-purple-500/40 text-purple-300 text-xs font-semibold backdrop-blur-md shadow-lg shadow-purple-900/30">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
            <span>Studio Mondial d'Animation IA • Rendu 4K 60FPS</span>
            <span className="hidden sm:inline text-purple-500">|</span>
            <span className="hidden sm:inline text-amber-300 font-bold">100% Vos Droits d'Auteur</span>
          </div>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.1] font-cinzel">
            Créez votre propre <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500 bg-clip-text text-transparent">
              animé japonais en 4K
            </span>{' '}
            de A à Z.
          </h1>

          <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed max-w-3xl mx-auto">
            Transformez vos idées, vos scénarios et vos propres photos en véritables films d'animation. 
            De <strong className="text-amber-300 font-semibold">1 seconde à 10 heures</strong> de vidéo fluide, 
            avec des personnages qui parlent et bougent comme dans les plus grands studios de Tokyo.
          </p>

          {/* Call to Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onStartFreeTrial}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 hover:brightness-110 shadow-xl shadow-amber-500/25 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-3"
            >
              <Sparkles className="w-5 h-5 text-slate-950" />
              <span>Commencer mes 3 essais gratuits</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>

            <button
              onClick={onExplorePlans}
              className="w-full sm:w-auto px-7 py-4 rounded-xl text-base font-semibold text-slate-200 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 hover:border-purple-500/60 shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>Découvrir les 8 Abonnements</span>
            </button>
          </div>

          <p className="text-xs text-slate-400 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Aucune carte bancaire requise pour débuter • Validation instantanée</span>
          </p>
        </div>

        {/* 4 Key Pillars Required in Prompt */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-glass border border-white/5 hover:border-amber-500/40 transition-all group">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-3 group-hover:scale-110 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Durée 100% sur-mesure</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              De 1 seconde à 10 heures d'animé fluide réglées à la minute près selon vos ambitions.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-glass border border-white/5 hover:border-purple-500/40 transition-all group">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-3 group-hover:scale-110 transition-transform">
              <Camera className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Vos photos prennent vie</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Importez vos visages réels, croquis manga ou décors : l'IA les transforme en protagonistes animés.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-glass border border-white/5 hover:border-cyan-500/40 transition-all group">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3 group-hover:scale-110 transition-transform">
              <MessageSquare className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Studio Collaboratif Intégré</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Messagerie en direct style WhatsApp pour co-réaliser des animés en équipe et échanger vos scripts.
            </p>
          </div>

          <div 
            onClick={onOpenRightsModal}
            className="p-5 rounded-2xl bg-glass border border-white/5 hover:border-emerald-500/40 transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-3 group-hover:scale-110 transition-transform">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-emerald-300 mb-1 flex items-center justify-between">
              <span>100% Vos Droits d'Auteur</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Vous conservez 100% de la propriété intellectuelle sur vos scénarios, personnages et vidéos générées.
            </p>
          </div>
        </div>

        {/* 4K Cinematic Studio Interactive Preview */}
        <div className="mt-16 rounded-3xl bg-gradient-to-b from-purple-950/40 via-slate-900/60 to-black/80 p-2 sm:p-4 border border-purple-500/30 shadow-2xl shadow-purple-950/60 relative">
          
          {/* Top Bar of the Studio Monitor */}
          <div className="flex flex-wrap items-center justify-between px-3 py-2 border-b border-purple-900/40 mb-3 gap-2">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
              </div>
              <span className="text-xs font-mono-code text-slate-400 ml-2">
                KamuiEngine_RenderPreview_4K_60FPS.mp4
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex bg-slate-950/60 p-0.5 rounded-lg border border-slate-800 text-[11px]">
                <button
                  onClick={() => setActivePreviewStyle('shonen')}
                  className={`px-2.5 py-1 rounded ${activePreviewStyle === 'shonen' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  Tokyo Shōnen
                </button>
                <button
                  onClick={() => setActivePreviewStyle('kyoto')}
                  className={`px-2.5 py-1 rounded ${activePreviewStyle === 'kyoto' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  Kyoto Romance
                </button>
                <button
                  onClick={() => setActivePreviewStyle('cyber')}
                  className={`px-2.5 py-1 rounded ${activePreviewStyle === 'cyber' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'}`}
                >
                  Shibuya Cyber 4K
                </button>
              </div>

              <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                Direct 4K
              </span>
            </div>
          </div>

          {/* Video Simulation Canvas */}
          <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-slate-800">
            {/* Visual Backdrops based on active style */}
            <div className="absolute inset-0 transition-all duration-700">
              {activePreviewStyle === 'shonen' && (
                <div className="w-full h-full bg-gradient-to-br from-indigo-950 via-[#0a0f24] to-[#1a0528] relative flex items-center justify-center">
                  {/* Stylized Anime Elements */}
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.25),transparent_70%)]" />
                  
                  {/* Glowing katana sword and sparks */}
                  <div className="absolute w-[2px] h-[70%] bg-gradient-to-t from-transparent via-cyan-300 to-white rotate-45 shadow-[0_0_20px_#38bdf8] animate-pulse" />
                  <div className="absolute w-40 h-40 rounded-full border border-cyan-400/30 animate-spin" style={{ animationDuration: '12s' }} />

                  {/* Character silhouette overlay */}
                  <div className="relative z-10 text-center space-y-3">
                    <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-b from-purple-500/30 to-indigo-900/40 border-2 border-purple-400/60 p-2 flex items-center justify-center glow-purple">
                      <span className="text-4xl">⚔️</span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xl font-bold text-white font-cinzel tracking-wider">
                        "L'Éveil du Katana Astral"
                      </h4>
                      <p className="text-xs text-cyan-300 font-mono-code">
                        Studio Mappa x Tokyo Action • Synchronisation labiale active
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activePreviewStyle === 'kyoto' && (
                <div className="w-full h-full bg-gradient-to-br from-rose-950 via-[#1f0d1e] to-[#0d0914] relative flex items-center justify-center">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(244,63,94,0.25),transparent_70%)]" />
                  
                  {/* Floating cherry blossom simulation */}
                  <div className="absolute top-10 left-1/4 text-rose-300 opacity-60 animate-bounce">🌸</div>
                  <div className="absolute bottom-16 right-1/4 text-rose-300 opacity-70 animate-pulse">🌸</div>
                  <div className="absolute top-1/2 right-1/3 text-pink-200 opacity-50">✨</div>

                  <div className="relative z-10 text-center space-y-3">
                    <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-b from-rose-500/30 to-pink-900/40 border-2 border-rose-400/60 p-2 flex items-center justify-center glow-gold">
                      <span className="text-4xl">🌸</span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xl font-bold text-white font-cinzel tracking-wider">
                        "Sous les Cerisiers de Minuit"
                      </h4>
                      <p className="text-xs text-rose-300 font-mono-code">
                        Kyoto Romance • Douceur aquarelle & Émotion 4K
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activePreviewStyle === 'cyber' && (
                <div className="w-full h-full bg-gradient-to-br from-cyan-950 via-[#07131d] to-[#12071f] relative flex items-center justify-center">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_60%,rgba(6,182,212,0.3),transparent_70%)]" />
                  
                  {/* Cyber Grid Lines */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#06b6d410_1px,transparent_1px),linear-gradient(to_bottom,#06b6d410_1px,transparent_1px)] bg-[size:4rem_4rem]" />

                  <div className="relative z-10 text-center space-y-3">
                    <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-b from-cyan-500/30 to-purple-900/40 border-2 border-cyan-400/60 p-2 flex items-center justify-center glow-cyan">
                      <span className="text-4xl">⚡</span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xl font-bold text-white font-cinzel tracking-wider">
                        "Shibuya 2099 : Cyber Shinobi"
                      </h4>
                      <p className="text-xs text-cyan-400 font-mono-code">
                        J-One Cyber-Pop • Éclairage volumétrique & Hologrammes
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Simulated Watermark for Free Trial (Notice rule: disappears on paid pack!) */}
            <div className="absolute top-4 right-4 z-20 px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-md border border-white/20 text-[11px] font-cinzel font-bold text-amber-300/80 tracking-widest pointer-events-none">
              KAMUI STUDIO • ESSAI GRATUIT
            </div>

            {/* Video Controls Overlay */}
            <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between bg-black/60 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/10">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-8 h-8 rounded-lg bg-purple-600 hover:bg-purple-500 text-white flex items-center justify-center transition-colors"
                >
                  <Play className={`w-4 h-4 fill-white ${isPlaying ? 'opacity-80' : ''}`} />
                </button>
                <div className="text-xs font-mono-code text-slate-300">
                  00:04:12 / 01:30:00
                </div>
                <div className="hidden sm:block w-32 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div className="w-1/3 h-full bg-gradient-to-r from-purple-500 to-amber-400 rounded-full" />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 text-slate-400 hover:text-white transition-colors"
                  title="Audio Japonaise / VF"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                </button>
                <button
                  onClick={() => setActiveView('studio')}
                  className="px-3 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Ouvrir dans le Studio</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
