import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  Mail, 
  User as UserIcon, 
  Phone, 
  Globe, 
  Sparkles, 
  AlertCircle,
  Eye,
  EyeOff,
  CheckCircle2
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'signup';
}

const COUNTRY_DIAL_CODES = [
  { code: 'CI', name: "Côte d'Ivoire", dial: '+225' },
  { code: 'SN', name: 'Sénégal', dial: '+221' },
  { code: 'CM', name: 'Cameroun', dial: '+237' },
  { code: 'BF', name: 'Burkina Faso', dial: '+226' },
  { code: 'ML', name: 'Mali', dial: '+223' },
  { code: 'BJ', name: 'Bénin', dial: '+229' },
  { code: 'TG', name: 'Togo', dial: '+228' },
  { code: 'NE', name: 'Niger', dial: '+227' },
  { code: 'GA', name: 'Gabon', dial: '+241' },
  { code: 'CG', name: 'Congo', dial: '+242' },
  { code: 'CD', name: 'RDC', dial: '+243' },
  { code: 'GN', name: 'Guinée', dial: '+224' },
  { code: 'FR', name: 'France', dial: '+33' },
  { code: 'BE', name: 'Belgique', dial: '+32' },
  { code: 'CH', name: 'Suisse', dial: '+41' },
  { code: 'CA', name: 'Canada', dial: '+1' },
  { code: 'US', name: 'États-Unis', dial: '+1' },
  { code: 'JP', name: 'Japon', dial: '+81' },
  { code: 'NG', name: 'Nigeria', dial: '+234' },
  { code: 'GH', name: 'Ghana', dial: '+233' },
  { code: 'MA', name: 'Maroc', dial: '+212' },
  { code: 'GB', name: 'Royaume-Uni', dial: '+44' },
  { code: 'OTHER', name: 'Autre pays mondial', dial: '+00' },
];

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode = 'login' }) => {
  const { login, signup } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(COUNTRY_DIAL_CODES[0]);
  const [phoneNumber, setPhoneNumber] = useState('');
  
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setLoading(true);

    setTimeout(() => {
      if (mode === 'login') {
        const result = login(email, password);
        if (result.success) {
          setSuccessMessage(result.message);
          setTimeout(() => {
            setLoading(false);
            onClose();
          }, 800);
        } else {
          setErrorMessage(result.message);
          setLoading(false);
        }
      } else {
        if (!name.trim()) {
          setErrorMessage('Veuillez saisir votre nom ou pseudo de créateur.');
          setLoading(false);
          return;
        }
        const fullPhone = `${selectedCountry.dial} ${phoneNumber}`;
        const result = signup({
          name,
          email,
          pass: password,
          phone: fullPhone,
          country: selectedCountry.name,
          countryCode: selectedCountry.code,
        });

        if (result.success) {
          setSuccessMessage(result.message);
          setTimeout(() => {
            setLoading(false);
            onClose();
          }, 900);
        } else {
          setErrorMessage(result.message);
          setLoading(false);
        }
      }
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-3xl bg-[#090d1c] border border-purple-500/40 p-6 sm:p-8 shadow-2xl shadow-purple-950/80">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-700 to-amber-400 p-[1.5px] shadow-lg shadow-purple-900/50 mb-3">
            <div className="w-full h-full bg-[#090d1c] rounded-[14px] flex items-center justify-center">
              <Lock className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <h2 className="text-2xl font-black text-white font-cinzel">
            {mode === 'login' ? 'Connexion Studio' : 'Créer mon Compte Studio'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {mode === 'login' 
              ? 'Accédez à vos animés 4K et vos crédits de création' 
              : 'Rejoignez le studio mondial • 3 essais gratuits offerts'}
          </p>
        </div>

        {/* Error / Success Alerts */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/70 border border-rose-500/60 text-xs text-rose-200 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-xs text-emerald-200 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nom ou Pseudo de Créateur
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  placeholder="ex: Kaito Tanaka"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-purple-500 text-sm text-white focus:outline-none transition-colors"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Adresse E-mail
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                placeholder="votre.email@domaine.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-purple-500 text-sm text-white focus:outline-none transition-colors"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Pays & Numéro Mobile (Tous pays acceptés)
              </label>
              <div className="flex gap-2">
                <select
                  value={selectedCountry.code}
                  onChange={(e) => {
                    const match = COUNTRY_DIAL_CODES.find((c) => c.code === e.target.value);
                    if (match) setSelectedCountry(match);
                  }}
                  className="w-2/5 px-2 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-purple-500 text-xs text-white focus:outline-none"
                >
                  {COUNTRY_DIAL_CODES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.dial} ({c.name})
                    </option>
                  ))}
                </select>
                <div className="relative w-3/5">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    placeholder="07 00 00 00"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-purple-500 text-sm text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Mot de Passe Sécurisé
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-purple-500 text-sm text-white focus:outline-none transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-xl text-sm font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
          >
            {loading ? (
              <span className="animate-spin w-4 h-4 border-2 border-black border-t-transparent rounded-full" />
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>
                  {mode === 'login' ? 'Se Connecter au Studio' : 'Démarrer mes 3 Essais Gratuits'}
                </span>
              </>
            )}
          </button>
        </form>

        {/* Security & Anti-Hack Assurance Notice */}
        <div className="mt-4 pt-4 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5 mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sécurité anti-piratage active • Chiffrement SHA-256 de bout en bout</span>
          </p>

          <button
            onClick={() => {
              setMode(mode === 'login' ? 'signup' : 'login');
              setErrorMessage(null);
            }}
            className="text-xs text-purple-400 hover:text-purple-300 font-semibold"
          >
            {mode === 'login'
              ? "Pas encore de compte ? Créer mon compte (3 essais gratuits)"
              : 'Déjà un compte ? Connectez-vous ici'}
          </button>
        </div>

      </div>
    </div>
  );
};
