import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { sendGeminiChat, generateAnimeScript } from '../services/gemini';
import { CollaborativeChat } from './CollaborativeChat';
import { 
  Sparkles, 
  Film, 
  Play, 
  Pause, 
  RotateCcw, 
  Sliders, 
  Palette, 
  Users, 
  Mic, 
  MicOff, 
  Music, 
  Video, 
  Layers, 
  Upload, 
  Trash2, 
  Edit3, 
  Download, 
  Share2, 
  MessageSquare, 
  ShieldCheck, 
  Tv, 
  Volume2, 
  CheckCircle2, 
  Zap, 
  Wand2, 
  RefreshCw,
  Clock,
  Send,
  Eye,
  Camera
} from 'lucide-react';

export const STYLES_12 = [
  { id: 'shonen', name: 'Manga Shōnen', tag: 'Action & Énergie', color: 'from-blue-600 to-indigo-600', desc: 'Lignes d’action dynamiques, combats vifs, auras étincelantes.' },
  { id: 'shojo', name: 'Shōjo & Romance d’Amour', tag: 'Romance & Émotion', color: 'from-pink-500 to-rose-500', desc: 'Yeux expressifs, lumière douce, pétales et ambiances romantiques.' },
  { id: 'cinema4k', name: 'Anime Cinéma 4K', tag: 'Chef d’œuvre', color: 'from-amber-500 to-red-600', desc: 'Rendu digne des longs métrages cinématographiques de Tokyo.' },
  { id: 'donghua', name: 'Donghua 3D Épique', tag: 'Chine 3D', color: 'from-emerald-600 to-teal-600', desc: 'Style 3D haute fidélité inspiré des chefs-d’œuvre d’animation chinois.' },
  { id: 'manhua', name: 'Manhua Fantastique', tag: 'Cultivation & Magie', color: 'from-purple-600 to-cyan-500', desc: 'Univers mystiques, pouvoirs élémentaires et sortilèges grandioses.' },
  { id: 'us_modern', name: 'Animation Américaine Moderne', tag: 'Action USA', color: 'from-blue-500 to-cyan-400', desc: 'Traits fluides et cadrages percutants inspirés de Spider-Verse.' },
  { id: 'cartoon3d', name: 'Cartoon 3D Cinéma', tag: 'Volume & Relief', color: 'from-orange-500 to-yellow-500', desc: 'Textures soyeuses, expressions faciales caricaturales ultra-vivantes.' },
  { id: 'franco_belge', name: 'Animation Franco-Belge', tag: 'Ligne Claire & Bande Dessinée', color: 'from-amber-600 to-orange-600', desc: 'Élégance de la ligne claire et décors architecturaux soignés.' },
  { id: 'cyberpop', name: 'Style J-One Cyber-Pop', tag: 'Néon & Musique', color: 'from-fuchsia-600 to-pink-500', desc: 'Esthétique clips musicaux tokyoïtes, néons saturés et pop culture.' },
  { id: 'semireal', name: 'Semi-Réaliste Humain 4K', tag: 'Ultra-Fidélité', color: 'from-slate-600 to-slate-900', desc: 'Proportions humaines réalistes, micro-détails de peau et cheveux.' },
  { id: 'aquarelle', name: 'Aquarelle & Nature Poétique', tag: 'Mousse & Forêt', color: 'from-emerald-500 to-green-600', desc: 'Décors de mousse luxuriante, pluie apaisante et esprit de la nature.' },
  { id: 'webtoon', name: 'Webtoon Vertical', tag: 'Format Mobile', color: 'from-violet-600 to-purple-800', desc: 'Colorimétrie percutante optimisée pour la lecture sur smartphone.' },
];

export const STUDIOS_15 = [
  { id: 'tokyo', name: 'Tokyo Action Studio', country: 'Japon', specialty: 'Combats d’épée & auras', color: 'border-blue-500' },
  { id: 'kyoto', name: 'Kyoto Romance Studio', country: 'Japon', specialty: 'Lumière volumétrique & émotion', color: 'border-rose-500' },
  { id: 'shibuya', name: 'Shibuya Neon (J-One)', country: 'Japon', specialty: 'Esthétique urbaine & cyber-pop', color: 'border-fuchsia-500' },
  { id: 'ghibli', name: 'Ghibli-Art Studio', country: 'Japon', specialty: 'Peinture de paysages & poésie pastorale', color: 'border-emerald-500' },
  { id: 'osaka', name: 'Osaka Shōnen Studio', country: 'Japon', specialty: 'Dynamisme comique & arts martiaux', color: 'border-amber-500' },
  { id: 'pekin', name: 'Pékin 3D Donghua', country: 'Chine', specialty: 'Textures soies, mythologie & épique', color: 'border-teal-500' },
  { id: 'shanghai', name: 'Shanghai Fantasy', country: 'Chine', specialty: 'Sorts lumineux & bêtes célestes', color: 'border-cyan-500' },
  { id: 'shenzhen', name: 'Shenzhen Cyber Tech', country: 'Chine', specialty: 'Mécha futuriste & hologrammes', color: 'border-indigo-500' },
  { id: 'hollywood', name: 'Hollywood 3D Studio', country: 'USA', specialty: 'Éclairage cinématique photoréaliste', color: 'border-red-500' },
  { id: 'burbank', name: 'Burbank Action', country: 'USA', specialty: 'Super-héros & dynamisme 60fps', color: 'border-sky-500' },
  { id: 'newyork', name: 'New York Comics', country: 'USA', specialty: 'Encrage noir profond & trames urbaines', color: 'border-slate-400' },
  { id: 'california', name: 'California Dream', country: 'USA', specialty: 'Couleurs chaudes & animation fluide', color: 'border-yellow-500' },
  { id: 'paris', name: 'Paris Animation Studio', country: 'France', specialty: 'Direction artistique d’auteur & poésie', color: 'border-purple-500' },
  { id: 'lyon', name: 'Lyon Créatif', country: 'France', specialty: 'Jeux de lumière & stylisation graphique', color: 'border-violet-500' },
  { id: 'bruxelles', name: 'Bruxelles Aventure', country: 'Belgique', specialty: 'Aventure épique & découpage classique', color: 'border-orange-500' },
];

export const CreationStudio: React.FC = () => {
  const { user, consumeCredit, currentPlan } = useAuth();
  
  // Studio navigation tabs:
  // 'private_editor' = Mode Privé (Edition avancée personnages/décors)
  // 'tab1_encyclopedia' = Assistant & Encyclopédie Mondiale
  // 'tab2_styles' = 12 Styles & 15 Grands Studios
  // 'tab3_casting' = Casting 100k Photos & Clonage Vidéo
  // 'tab4_voice_music' = Clonage Vocal & Studio Musique
  // 'tab5_shorts_ads' = Formats Courts TikTok & Publicités 4K
  const [activeTab, setActiveTab] = useState<
    'private_editor' | 'tab1_encyclopedia' | 'tab2_styles' | 'tab3_casting' | 'tab4_voice_music' | 'tab5_shorts_ads'
  >('private_editor');

  const [collaborativeChatOpen, setCollaborativeChatOpen] = useState(false);

  // Private Mode Generation State
  const [promptText, setPromptText] = useState(
    "Un jeune maître d'armes aux cheveux d'argent affronte son rival sous une pluie battante devant le temple ancestral. Éclairage néon violet et reflets dans les flaques."
  );
  const [characterPhoto, setCharacterPhoto] = useState<string | null>(null);
  const [selectedMood, setSelectedMood] = useState<'Action' | 'Drame' | 'Romance' | 'Fantastique' | 'Cyberpunk' | 'Musique'>('Action');
  const [durationHours, setDurationHours] = useState(0);
  const [durationMinutes, setDurationMinutes] = useState(2);
  const [durationSeconds, setDurationSeconds] = useState(30);

  // Advanced Scene Modification Controls (Required in Mode Privé)
  const [characterModifier, setCharacterModifier] = useState({
    active: true,
    outfit: 'Armure samouraï néon',
    hairColor: 'Argent étincelant',
    facialExpression: 'Regard déterminé & intense',
  });
  const [landscapeModifier, setLandscapeModifier] = useState({
    active: true,
    timeOfDay: 'Nuit pluvieuse',
    weather: 'Orage électrique & gouttes en suspension',
    lighting: 'Reflets néon violet et cyan',
  });
  const [characterRemoved, setCharacterRemoved] = useState(false);
  const [landscapeRemoved, setLandscapeRemoved] = useState(false);

  // Video Canvas Simulation State
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [videoGenerated, setVideoGenerated] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [lipSyncSpeaking, setLipSyncSpeaking] = useState(false);
  const [selectedStyleId, setSelectedStyleId] = useState('shonen');
  const [selectedStudioId, setSelectedStudioId] = useState('tokyo');
  const [replicateSignature, setReplicateSignature] = useState(true);

  // Tab 1: AI Assistant & Encyclopedia Chat
  const [aiChatMessages, setAiChatMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    {
      sender: 'ai',
      text: "Bonjour ! Je suis l'Assistant & Encyclopédie Mondiale des Animés de Kamui Studio 4K. Je connais l'histoire, les techniques secrètes et les signatures visuelles de tous les studios japonais, chinois, français et américains. Quel univers ou scénario souhaitez-vous concevoir aujourd'hui ?",
    },
  ]);
  const [aiInput, setAiInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Tab 3: Casting 100k Photos & Video Motion Cloning
  const [castCount, setCastCount] = useState(154);
  const [clonedMotionFile, setClonedMotionFile] = useState<string | null>(null);
  const [motionChoreography, setMotionChoreography] = useState('Chorégraphie sabre 360° style Studio Mappa');

  // Tab 4: Voice Cloning & Music Studio
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVoiceSample, setRecordedVoiceSample] = useState<string | null>(null);
  const [selectedVoicePreset, setSelectedVoicePreset] = useState('Shōnen Héros Déterminé (JP/FR)');
  const [bgmGenre, setBgmGenre] = useState('Opening Épique avec Chœurs & Guitare Électrique');
  const [musicStatus, setMusicStatus] = useState<string | null>(null);

  // Tab 5: Shorts & Ads
  const [shortTopic, setShortTopic] = useState('Spot publicitaire pour marque de boisson énergisante anime 4K');
  const [shortFormat, setShortFormat] = useState<'9:16' | '16:9'>('9:16');
  const [shortResult, setShortResult] = useState<string | null>(null);

  // Lip-sync speech simulation
  const handleTriggerLipSync = () => {
    if (lipSyncSpeaking) return;
    setLipSyncSpeaking(true);
    
    // Use Web Speech Synthesis if supported
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(
        "Mon katana est lié à la vérité. Jamais je ne renoncerai à mon destin !"
      );
      utterance.rate = 1.05;
      utterance.pitch = 1.1;
      utterance.onend = () => setLipSyncSpeaking(false);
      utterance.onerror = () => setLipSyncSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setTimeout(() => setLipSyncSpeaking(false), 3000);
    }
  };

  // Launch Video Generation
  const handleGenerateVideo = () => {
    const hasCredit = consumeCredit();
    if (!hasCredit && (!user || user.credits <= 0)) {
      alert("Vous avez épuisé vos crédits. Veuillez souscrire à un pack pour continuer à créer sans limite.");
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);

    const interval = setInterval(() => {
      setGenerationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsGenerating(false);
          setVideoGenerated(true);
          setIsPlaying(true);
          return 100;
        }
        return prev + 15;
      });
    }, 250);
  };

  // Handle AI Chat
  const handleSendAiMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim() || isAiLoading) return;

    const userMsg = aiInput.trim();
    setAiChatMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setAiInput('');
    setIsAiLoading(true);

    try {
      const reply = await sendGeminiChat(
        userMsg,
        `Style actuel: ${selectedStyleId}, Studio: ${selectedStudioId}, Scénario: ${promptText}`
      );
      setAiChatMessages((prev) => [...prev, { sender: 'ai', text: reply }]);
    } catch (e) {
      setAiChatMessages((prev) => [
        ...prev,
        { sender: 'ai', text: "Erreur lors de la consultation de l'encyclopédie. Veuillez réessayer." },
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Voice recording simulation
  const handleToggleVoiceRecord = () => {
    if (!isRecording) {
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        setRecordedVoiceSample('Audio_EmpreinteVocale_01.wav (100% calibré)');
      }, 2500);
    } else {
      setIsRecording(false);
    }
  };

  return (
    <div className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Studio Header Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-6 border-b border-purple-900/40 gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black text-white font-cinzel">
              Studio de Création 4K
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Moteur Kamui v4.8
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Génération cinématique complète • 100% de vos droits de propriété intellectuelle conservés
          </p>
        </div>

        {/* Top Actions: Collaborative Chat & Credits Info */}
        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold">
            <span className="text-slate-400">Statut : </span>
            <span className="text-amber-400 font-bold">
              {user?.isAdmin
                ? 'Propriétaire (Illimité 4K)'
                : user?.planId === 'free' || !user
                ? `${user?.credits || 3} Essais Gratuits`
                : `${currentPlan?.name || 'VIP'} Actif`}
            </span>
          </div>

          <button
            onClick={() => setCollaborativeChatOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/50 border border-purple-500/40 text-purple-200 text-xs font-bold transition-all flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4 text-purple-400" />
            <span>Studio Collaboratif (WhatsApp)</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs (All 5 Main Studio Tabs + Mode Privé) */}
      <div className="mt-6 flex flex-wrap gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('private_editor')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'private_editor'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Film className="w-4 h-4 text-amber-300" />
          <span>Mode Privé (Édition Scène & Personnages)</span>
        </button>

        <button
          onClick={() => setActiveTab('tab1_encyclopedia')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'tab1_encyclopedia'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-cyan-300" />
          <span>1. Assistant & Encyclopédie Mondiale</span>
        </button>

        <button
          onClick={() => setActiveTab('tab2_styles')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'tab2_styles'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Palette className="w-4 h-4 text-pink-300" />
          <span>2. 12 Styles & 15 Grands Studios</span>
        </button>

        <button
          onClick={() => setActiveTab('tab3_casting')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'tab3_casting'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Users className="w-4 h-4 text-amber-300" />
          <span>3. Casting 100k Photos & Clonage Vidéo</span>
        </button>

        <button
          onClick={() => setActiveTab('tab4_voice_music')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'tab4_voice_music'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Mic className="w-4 h-4 text-rose-300" />
          <span>4. Clonage Vocal & Studio Musique</span>
        </button>

        <button
          onClick={() => setActiveTab('tab5_shorts_ads')}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'tab5_shorts_ads'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-900/40'
              : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
          }`}
        >
          <Tv className="w-4 h-4 text-emerald-300" />
          <span>5. Formats Courts & Publicités 4K</span>
        </button>
      </div>

      {/* Main Studio Work Area */}
      <div className="mt-6">
        
        {/* ========================================================= */}
        {/* TAB 0 / MODE PRIVÉ : ÉDITION AVANCÉE SCÈNE & PERSONNAGES  */}
        {/* ========================================================= */}
        {activeTab === 'private_editor' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Controls Column (5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              
              {/* Scenario Prompt Input */}
              <div className="p-4 rounded-2xl bg-glass-card border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white flex items-center gap-2">
                    <Wand2 className="w-4 h-4 text-purple-400" />
                    <span>Scénario, Dialogues & Actions de la Scène</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono-code">Prompt IA</span>
                </div>
                <textarea
                  rows={4}
                  value={promptText}
                  onChange={(e) => setPromptText(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-950/80 border border-slate-700/80 focus:border-purple-500 text-xs text-white leading-relaxed focus:outline-none resize-none"
                  placeholder="Décrivez les actions, l'ambiance, les mouvements de caméra et les répliques..."
                />
              </div>

              {/* Photo & Croquis Importer (Transforms real faces into manga) */}
              <div className="p-4 rounded-2xl bg-glass-card border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white flex items-center gap-2">
                    <Camera className="w-4 h-4 text-cyan-400" />
                    <span>Importation de Visages, Photos & Croquis</span>
                  </label>
                  <span className="text-[10px] text-emerald-400 font-semibold">Transformé en Manga</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                    {characterPhoto ? (
                      <img src={characterPhoto} alt="Casting" className="w-full h-full object-cover" />
                    ) : (
                      <Users className="w-6 h-6 text-slate-500" />
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <label className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5 text-purple-400" />
                      <span>Charger une photo / dessin</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = () => setCharacterPhoto(reader.result as string);
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    <p className="text-[10px] text-slate-400">
                      L'IA modélise le visage avec expressions et synchronisation labiale.
                    </p>
                  </div>
                </div>
              </div>

              {/* EXCLUSIVE REQUIREMENT: ADVANCED EDITING CONTROLS IN PRIVATE MODE */}
              {/* "modifier des personnages, modifier des paysages, supprimer des personnages et supprimer des paysages" */}
              <div className="p-4 rounded-2xl bg-gradient-to-b from-purple-950/40 to-slate-900/60 border border-purple-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Outils d'Édition du Mode Privé</span>
                  </span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-amber-400/20 text-amber-300">
                    Exclusif Mode Privé
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  {/* Modifier Personnages */}
                  <button
                    onClick={() => {
                      const expressions = ['Regard déterminé', 'Sourire mystérieux', 'Colère Shōnen', 'Larmes d’émotion'];
                      const next = expressions[(expressions.indexOf(characterModifier.facialExpression) + 1) % expressions.length];
                      setCharacterModifier((prev) => ({ ...prev, facialExpression: next }));
                    }}
                    className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-purple-900/30 border border-purple-500/40 text-left transition-colors"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300">
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Modifier Personnages</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 truncate">
                      {characterModifier.facialExpression}
                    </p>
                  </button>

                  {/* Modifier Paysages */}
                  <button
                    onClick={() => {
                      const ambiances = ['Nuit pluvieuse néon', 'Coucher de soleil doré', 'Brume mystique forêt', 'Orage électrique'];
                      const next = ambiances[(ambiances.indexOf(landscapeModifier.timeOfDay) + 1) % ambiances.length];
                      setLandscapeModifier((prev) => ({ ...prev, timeOfDay: next }));
                    }}
                    className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-cyan-900/30 border border-cyan-500/40 text-left transition-colors"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                      <Palette className="w-3.5 h-3.5" />
                      <span>Modifier Paysages</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 truncate">
                      {landscapeModifier.timeOfDay}
                    </p>
                  </button>

                  {/* Supprimer Personnages */}
                  <button
                    onClick={() => setCharacterRemoved(!characterRemoved)}
                    className={`p-2.5 rounded-xl border text-left transition-colors ${
                      characterRemoved
                        ? 'bg-rose-950/70 border-rose-500 text-rose-300'
                        : 'bg-slate-900/80 hover:bg-rose-950/30 border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold">
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{characterRemoved ? 'Personnage Masqué' : 'Supprimer Personnage'}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      {characterRemoved ? 'Isoler uniquement le décor' : 'Effacer le personnage'}
                    </p>
                  </button>

                  {/* Supprimer Paysages */}
                  <button
                    onClick={() => setLandscapeRemoved(!landscapeRemoved)}
                    className={`p-2.5 rounded-xl border text-left transition-colors ${
                      landscapeRemoved
                        ? 'bg-amber-950/70 border-amber-500 text-amber-300'
                        : 'bg-slate-900/80 hover:bg-amber-950/30 border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold">
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{landscapeRemoved ? 'Décor Retiré' : 'Supprimer Paysage'}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">
                      {landscapeRemoved ? 'Fond transparent 4K' : 'Effacer l’arrière-plan'}
                    </p>
                  </button>
                </div>
              </div>

              {/* Precise Duration Selector (Heures : Minutes : Secondes) */}
              <div className="p-4 rounded-2xl bg-glass-card border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>Réglage Précis de la Durée (H : Min : Sec)</span>
                  </label>
                  <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                    Max autorisé : {user?.isAdmin ? 'Illimité (10h+)' : currentPlan ? currentPlan.maxVideoDuration : '15 sec (Essai)'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="p-2 rounded-xl bg-slate-950 text-center border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Heures</span>
                    <input
                      type="number"
                      min={0}
                      max={10}
                      value={durationHours}
                      onChange={(e) => setDurationHours(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full text-center bg-transparent text-sm font-bold text-white font-mono-code focus:outline-none"
                    />
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950 text-center border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Minutes</span>
                    <input
                      type="number"
                      min={0}
                      max={59}
                      value={durationMinutes}
                      onChange={(e) => setDurationMinutes(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full text-center bg-transparent text-sm font-bold text-white font-mono-code focus:outline-none"
                    />
                  </div>
                  <div className="p-2 rounded-xl bg-slate-950 text-center border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Secondes</span>
                    <input
                      type="number"
                      min={0}
                      max={59}
                      value={durationSeconds}
                      onChange={(e) => setDurationSeconds(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full text-center bg-transparent text-sm font-bold text-white font-mono-code focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Mood Selector */}
              <div className="p-4 rounded-2xl bg-glass-card border border-white/10 space-y-2">
                <label className="text-xs font-bold text-white block">
                  Ambiance Cinématographique & Effets Sonores
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['Action', 'Drame', 'Romance', 'Fantastique', 'Cyberpunk', 'Musique'] as const).map((mood) => (
                    <button
                      key={mood}
                      onClick={() => setSelectedMood(mood)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition-all ${
                        selectedMood === mood
                          ? 'bg-amber-400 text-slate-950 font-bold'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {mood}
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate CTA Button */}
              <button
                onClick={handleGenerateVideo}
                disabled={isGenerating}
                className="w-full py-4 rounded-2xl text-sm font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-xl shadow-amber-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
                    <span>Rendu Kamui 4K en cours ({generationProgress}%)...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-slate-950" />
                    <span>Lancer la Génération Vidéo 4K</span>
                  </>
                )}
              </button>

            </div>

            {/* Right Video Canvas Monitor (7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* Video Player Display Container */}
              <div className="relative aspect-video w-full rounded-3xl overflow-hidden bg-black border border-purple-500/30 shadow-2xl flex items-center justify-center">
                
                {/* Background Environment (Hidden if landscapeRemoved) */}
                {!landscapeRemoved ? (
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-[#0a0d1f] to-[#1a0826] transition-all">
                    {/* Simulated Weather & Lighting Particles */}
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(147,51,234,0.3),transparent_70%)]" />
                    
                    {/* Neon rain drops effect */}
                    <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px]" />
                    
                    {/* Dynamic Ambient Horizon Light */}
                    <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-purple-900/40 via-cyan-900/20 to-transparent" />
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-slate-950 flex items-center justify-center">
                    <span className="text-xs text-slate-400 font-mono-code">
                      [Fond Décor Retiré • Isolé 4K Studio]
                    </span>
                  </div>
                )}

                {/* Character Presence (Hidden if characterRemoved) */}
                {!characterRemoved && (
                  <div className="relative z-10 flex flex-col items-center space-y-3">
                    
                    {/* Animated Anime Character Avatar with Lip Sync */}
                    <div className={`relative w-40 h-40 rounded-full border-2 border-purple-400 p-2 shadow-2xl transition-all duration-300 ${
                      lipSyncSpeaking ? 'scale-105 border-amber-400 glow-gold' : 'glow-purple'
                    }`}>
                      <div className="w-full h-full rounded-full bg-gradient-to-b from-purple-800/40 to-slate-900 overflow-hidden flex items-center justify-center relative">
                        {characterPhoto ? (
                          <img src={characterPhoto} alt="Character" className="w-full h-full object-cover" />
                        ) : (
                          <div className="text-center space-y-1">
                            <span className="text-5xl">🥷</span>
                            <div className="text-[10px] font-bold text-cyan-300 font-mono-code">
                              {characterModifier.hairColor}
                            </div>
                          </div>
                        )}

                        {/* Lip Sync Mouth Wave Indicator */}
                        {lipSyncSpeaking && (
                          <div className="absolute bottom-3 inset-x-0 flex items-center justify-center gap-1">
                            <span className="w-1.5 h-3 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <span className="w-1.5 h-5 bg-amber-300 rounded-full animate-bounce" style={{ animationDelay: '100ms' }} />
                            <span className="w-1.5 h-2 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '200ms' }} />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Dialogue Subtitle Overlay */}
                    <div className="px-4 py-2 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 max-w-md text-center">
                      <p className="text-xs text-white font-medium italic">
                        "{lipSyncSpeaking 
                          ? "Mon katana est lié à la vérité. Jamais je ne renoncerai à mon destin !" 
                          : "Prêt pour le combat sous la brume de Néo-Tokyo."}"
                      </p>
                    </div>
                  </div>
                )}

                {/* Watermark Notice: Displays on free trial, REMOVED completely for paid subscribers! */}
                {(!user || user.planId === 'free') && (
                  <div className="absolute top-4 right-4 z-20 px-3 py-1.5 rounded-lg bg-black/70 backdrop-blur-md border border-white/20 text-[10px] font-cinzel font-bold text-amber-300 tracking-widest pointer-events-none">
                    KAMUI STUDIO • ESSAI GRATUIT
                  </div>
                )}

                {/* 4K Badge */}
                <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    4K ULTRA HD • 60 FPS
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono-code bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    {selectedMood}
                  </span>
                </div>

                {/* Video Controls Bar */}
                <div className="absolute bottom-4 inset-x-4 z-20 flex items-center justify-between bg-black/75 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                    </button>
                    
                    <button
                      onClick={handleTriggerLipSync}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
                        lipSyncSpeaking
                          ? 'bg-amber-400 text-slate-950 animate-pulse'
                          : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                      }`}
                      title="Activer la synchronisation labiale et faire parler le personnage"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>{lipSyncSpeaking ? 'Parole en cours...' : 'Faire Parler (Audio)'}</span>
                    </button>
                  </div>

                  <div className="text-xs font-mono-code text-slate-300">
                    {durationHours > 0 ? `${durationHours}h ` : ''}
                    {durationMinutes}m {durationSeconds}s
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => alert("Export MP4 4K généré dans votre dossier de téléchargements.")}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      title="Télécharger l'animé en MP4 4K"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => alert("Lien de partage privé copié.")}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      title="Partager"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Technical Specifications Summary */}
              <div className="p-4 rounded-2xl bg-glass border border-white/5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Définition</span>
                  <span className="font-bold text-white">3840 x 2160 (4K)</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Fréquence</span>
                  <span className="font-bold text-white">60 FPS Cinéma</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Droits d'Auteur</span>
                  <span className="font-bold text-emerald-400">100% Vos Droits</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Filigrane</span>
                  <span className="font-bold text-amber-300">
                    {user?.planId && user.planId !== 'free' ? 'Désactivé (VIP)' : 'Actif (Essai)'}
                  </span>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 1 : ASSISTANT & ENCYCLOPÉDIE MONDIALE DES ANIMÉS (GEMINI) */}
        {/* ========================================================= */}
        {activeTab === 'tab1_encyclopedia' && (
          <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  <span>Assistant & Encyclopédie Mondiale des Animés (Connecté à Gemini)</span>
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Connaît tous les animés du monde, fait des recherches sur les techniques des studios (chinois, américains, français, japonais) et génère des scénarios complets jusqu'à 2 heures.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
                IA Active
              </span>
            </div>

            {/* Quick Prompts Suggestions */}
            <div className="flex flex-wrap gap-2">
              {[
                "Écrire un animé d'amour nocturne sous les cerisiers",
                "Chorégraphie de combat au sabre style Studio Mappa",
                "Scénario d'ambiance nature, mousse et esprit de la forêt",
                "Série fantastique Donghua 3D en 12 épisodes",
              ].map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => setAiInput(suggestion)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-purple-900/30 border border-slate-800 text-xs text-slate-300 hover:text-white transition-colors"
                >
                  💡 {suggestion}
                </button>
              ))}
            </div>

            {/* Chat Messages Display */}
            <div className="h-96 overflow-y-auto p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-4">
              {aiChatMessages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div className="text-[10px] text-slate-400 mb-1 px-1">
                    {msg.sender === 'user' ? 'Vous' : 'Encyclopédie Kamui IA'}
                  </div>
                  <div
                    className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap ${
                      msg.sender === 'user'
                        ? 'bg-purple-600 text-white rounded-tr-none'
                        : 'bg-slate-900 text-slate-200 border border-purple-500/30 rounded-tl-none'
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              {isAiLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 italic">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Recherche encyclopédique et génération en cours...</span>
                </div>
              )}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendAiMessage} className="flex gap-2">
              <input
                type="text"
                placeholder="Posez une question sur un animé, demandez une technique de studio ou un scénario complet..."
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={isAiLoading}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs hover:brightness-110 flex items-center gap-2 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>Envoyer</span>
              </button>
            </form>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2 : 12 STYLES & 15 GRANDS STUDIOS INTERNATIONAUX      */}
        {/* ========================================================= */}
        {activeTab === 'tab2_styles' && (
          <div className="space-y-8">
            
            {/* Section 12 Styles */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white font-cinzel">
                    Les 12 Styles Artistiques Officiels
                  </h3>
                  <p className="text-xs text-slate-300">
                    Choisissez la signature esthétique principale de votre production 4K.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {STYLES_12.map((s) => {
                  const isSelected = selectedStyleId === s.id;
                  return (
                    <div
                      key={s.id}
                      onClick={() => setSelectedStyleId(s.id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-purple-950/60 border-purple-400 shadow-lg shadow-purple-900/30'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-bold text-white">{s.name}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-purple-400" />}
                      </div>
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-amber-300 mb-2">
                        {s.tag}
                      </span>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {s.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Section 15 World Studios */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xl font-bold text-white font-cinzel">
                    Les 15 Grands Studios Internationaux
                  </h3>
                  <p className="text-xs text-slate-300">
                    Japon, Chine, États-Unis, France, Belgique. L'algorithme reproduit fidèlement la signature visuelle.
                  </p>
                </div>

                <label className="flex items-center gap-2 text-xs font-semibold text-amber-300 cursor-pointer bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/30">
                  <input
                    type="checkbox"
                    checked={replicateSignature}
                    onChange={(e) => setReplicateSignature(e.target.checked)}
                    className="rounded text-amber-500 focus:ring-0"
                  />
                  <span>Copier fidèlement la signature visuelle</span>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {STUDIOS_15.map((studio) => {
                  const isSelected = selectedStudioId === studio.id;
                  return (
                    <div
                      key={studio.id}
                      onClick={() => setSelectedStudioId(studio.id)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-amber-950/60 border-amber-400 shadow-md shadow-amber-900/30'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-white">{studio.name}</span>
                        <span className="text-[9px] text-slate-400 font-mono-code">{studio.country}</span>
                      </div>
                      <p className="text-[10px] text-slate-400">{studio.specialty}</p>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3 : CASTING 100 000+ PHOTOS & CLONAGE VIDÉO           */}
        {/* ========================================================= */}
        {activeTab === 'tab3_casting' && (
          <div className="space-y-6">
            
            {/* Massive Gallery Module (150 to 100,000+ files) */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                    <Users className="w-5 h-5 text-amber-400" />
                    <span>Casting Haute Capacité (150 à 100 000+ Fichiers)</span>
                  </h3>
                  <p className="text-xs text-slate-300">
                    Importation de lots massifs de photos pour acteurs principaux et génération automatique de personnages secondaires cohérents avec mouvements humains naturels.
                  </p>
                </div>

                <label className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-2 cursor-pointer transition-colors shrink-0">
                  <Upload className="w-4 h-4" />
                  <span>Importer un Lot Massif (ZIP / Dossier)</span>
                  <input
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files) {
                        setCastCount((prev) => prev + e.target.files!.length);
                      }
                    }}
                  />
                </label>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Acteurs Principaux</span>
                  <span className="text-lg font-black text-amber-400 font-mono-code">12 Enregistrés</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Personnages Secondaires Auto</span>
                  <span className="text-lg font-black text-cyan-400 font-mono-code">{castCount} Générés</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Capacité Galerie</span>
                  <span className="text-lg font-black text-emerald-400 font-mono-code">100 000+ Visages</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Cohérence Anatomique</span>
                  <span className="text-lg font-black text-purple-400 font-mono-code">100% Naturel</span>
                </div>
              </div>

              {/* Casting Roster Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 pt-2">
                {[
                  { name: 'Kaito (Héros)', role: 'Guerrier Katana', emoji: '⚔️' },
                  { name: 'Aoi (Héroïne)', role: 'Mage Céleste', emoji: '✨' },
                  { name: 'Ren (Rival)', role: 'Ombre Shinjuku', emoji: '🌑' },
                  { name: 'Sensei Ryu', role: 'Maître Spirituel', emoji: '📜' },
                  { name: 'Hana', role: 'Guerrière Fleurs', emoji: '🌸' },
                  { name: 'Kuro', role: 'Cyber Ninja', emoji: '⚡' },
                ].map((char, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center space-y-1">
                    <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-2xl">
                      {char.emoji}
                    </div>
                    <div className="text-xs font-bold text-white truncate">{char.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{char.role}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Video Motion Cloning Module */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                  <Video className="w-5 h-5 text-purple-400" />
                  <span>Module : Clonage de Mouvements par Vidéo</span>
                </h3>
                <p className="text-xs text-slate-300">
                  Importez une vidéo d'animé pour copier les chorégraphies, styles de combat et mise en scène tout en modifiant le style graphique.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-center sm:text-left">
                  <span className="text-xs font-bold text-white block">
                    Source Vidéo de Référence
                  </span>
                  <span className="text-xs text-purple-300 font-mono-code">
                    {clonedMotionFile || 'Aucune vidéo importée (Exemple pré-chargé : Combat Sabre 60fps)'}
                  </span>
                </div>

                <label className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white flex items-center gap-2 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4 text-cyan-400" />
                  <span>Importer Vidéo de Combat (.mp4)</span>
                  <input
                    type="file"
                    accept="video/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        setClonedMotionFile(e.target.files[0].name);
                      }
                    }}
                  />
                </label>
              </div>
            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 4 : CLONAGE VOCAL & STUDIO MUSIQUE                    */}
        {/* ========================================================= */}
        {activeTab === 'tab4_voice_music' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Voice Cloning Box */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                  <Mic className="w-5 h-5 text-rose-400" />
                  <span>Enregistreur Vocal & Clonage de Voix</span>
                </h3>
                <p className="text-xs text-slate-300">
                  Enregistrez une courte phrase ("Bonjour", "Bonsoir") : l'IA attribue votre vraie voix au personnage choisi avec synchronisation labiale.
                </p>
              </div>

              {/* Mic Record Button */}
              <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-3">
                <button
                  onClick={handleToggleVoiceRecord}
                  className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center transition-all ${
                    isRecording
                      ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/50'
                      : 'bg-purple-600 hover:bg-purple-500 text-white'
                  }`}
                >
                  {isRecording ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>

                <div className="text-xs font-semibold text-white">
                  {isRecording ? 'Enregistrement de votre voix en cours...' : 'Cliquez pour enregistrer votre voix'}
                </div>
                <p className="text-[11px] text-slate-400">
                  Prononcez : "Bonjour, je suis le héros de cette aventure."
                </p>

                {recordedVoiceSample && (
                  <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300">
                    ✅ {recordedVoiceSample}
                  </div>
                )}
              </div>

              {/* Realistic Synthetic Voices Library */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-white block">
                  Bibliothèque de Voix Synthétiques Réalistes
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    'Shōnen Héros Déterminé (JP/FR)',
                    'Doux Romance & Poésie',
                    'Guerrier Sombre & Profond',
                    'Héroïne Cyberpunk Énergique',
                    'Narrateur Épique Cinématographique',
                    'Enfant Espiègle Manga',
                  ].map((voice, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedVoicePreset(voice)}
                      className={`p-2.5 rounded-xl border text-left text-xs font-medium transition-all ${
                        selectedVoicePreset === voice
                          ? 'bg-rose-950/60 border-rose-500 text-rose-200'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {voice}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Music Studio Box */}
            <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-4">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                  <Music className="w-5 h-5 text-amber-400" />
                  <span>Générateur de Chansons & OST d'Ambiance</span>
                </h3>
                <p className="text-xs text-slate-300">
                  Création de bandes originales complètes (Openings avec chants en japonais/français, thèmes de combat, pianos mélancoliques).
                </p>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-bold text-white block">
                  Style Musical & Genre de la Chanson
                </label>
                <div className="space-y-2">
                  {[
                    'Opening Épique avec Chœurs & Guitare Électrique',
                    'Ending Poétique : Piano Mélancolique & Violoncelles',
                    'OST de Combat Shōnen : Tambours Taiko & Basses Synth',
                    'Ambiance Cyberpunk Nocturne : Synthwave & Pluie',
                  ].map((genre, idx) => (
                    <button
                      key={idx}
                      onClick={() => setBgmGenre(genre)}
                      className={`w-full p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                        bgmGenre === genre
                          ? 'bg-amber-950/60 border-amber-400 text-amber-200'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      🎵 {genre}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => {
                    setMusicStatus('Génération de la bande son 4K Dolby Atmos terminée avec succès.');
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-bold text-xs hover:brightness-110 shadow-md"
                >
                  Générer la Chanson Complète (Audio HD)
                </button>

                {musicStatus && (
                  <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300">
                    ✅ {musicStatus}
                  </div>
                )}
              </div>
            </div>

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 5 : FORMATS COURTS (TIKTOK/REELS) & PUBLICITÉS 4K      */}
        {/* ========================================================= */}
        {activeTab === 'tab5_shorts_ads' && (
          <div className="p-6 rounded-3xl bg-glass-card border border-white/10 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-white font-cinzel flex items-center gap-2">
                  <Tv className="w-5 h-5 text-emerald-400" />
                  <span>Formats Courts (TikTok / YouTube Shorts) & Publicités 4K</span>
                </h3>
                <p className="text-xs text-slate-300">
                  Mode rapide pour générer des animés courts viraux ou des spots publicitaires de haute qualité à partir d'un simple texte.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-white block mb-1">
                    Texte ou Script Publicitaire
                  </label>
                  <textarea
                    rows={4}
                    value={shortTopic}
                    onChange={(e) => setShortTopic(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-400"
                    placeholder="ex: Spot publicitaire manga pour parfum de luxe ou marque de mode..."
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-white block mb-2">
                    Format d'Affichage Cible
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setShortFormat('9:16')}
                      className={`p-3 rounded-xl border text-xs font-bold transition-all ${
                        shortFormat === '9:16'
                          ? 'bg-emerald-950/60 border-emerald-400 text-emerald-200'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      📱 9:16 Vertical (TikTok / Shorts)
                    </button>
                    <button
                      onClick={() => setShortFormat('16:9')}
                      className={`p-3 rounded-xl border text-xs font-bold transition-all ${
                        shortFormat === '16:9'
                          ? 'bg-emerald-950/60 border-emerald-400 text-emerald-200'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      🖥️ 16:9 Horizontal (Publicité TV 4K)
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setShortResult(
                      `Spot Publicitaire Généré (Format ${shortFormat}) :\n- 00:00 - 00:03 : Accroche visuelle 4K explosive avec personnage anime buvant la canette\n- 00:03 - 00:10 : Éclairs néon cyan et boost d'énergie cinématique\n- 00:10 - 00:15 : Call-to-action percutant avec logo et musique dynamique.`
                    );
                  }}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-extrabold text-xs hover:brightness-110 shadow-lg shadow-emerald-500/20"
                >
                  Générer le Format Court Viral en 1 Clic
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-400 block">
                  Aperçu du Script & Storyboard Court
                </span>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 leading-relaxed font-mono-code min-h-[140px] whitespace-pre-wrap">
                  {shortResult || "Le scénario court et le découpage dynamique s'afficheront ici après génération..."}
                </div>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Embedded Real-Time Collaborative Chat Drawer */}
      <CollaborativeChat
        isOpen={collaborativeChatOpen}
        onClose={() => setCollaborativeChatOpen(false)}
      />

    </div>
  );
};
