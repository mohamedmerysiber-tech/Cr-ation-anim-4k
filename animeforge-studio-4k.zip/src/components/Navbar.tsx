import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { CURRENCIES, CURRENCY_CODES, CurrencyCode } from '../services/currency';
import { 
  Sparkles, 
  Crown, 
  User as UserIcon, 
  Globe, 
  ShieldCheck, 
  Film, 
  CreditCard, 
  LogOut, 
  Menu, 
  X,
  ChevronDown,
  Layers
} from 'lucide-react';

interface NavbarProps {
  onOpenAuth: (initialMode?: 'login' | 'signup') => void;
  onOpenRightsModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAuth, onOpenRightsModal }) => {
  const { user, selectedCurrency, setSelectedCurrency, activeView, setActiveView, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-900/30 bg-[#070a14]/90 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Brand */}
          <div 
            onClick={() => setActiveView('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-amber-400 p-[1.5px] shadow-lg shadow-purple-900/40 group-hover:shadow-purple-600/50 transition-all duration-300">
              <div className="w-full h-full bg-[#070a14] rounded-[10px] flex items-center justify-center">
                <Film className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-wider bg-gradient-to-r from-white via-slate-100 to-amber-300 bg-clip-text text-transparent font-cinzel">
                  KAMUI <span className="text-purple-400">STUDIO</span>
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-widest bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded">
                  4K HDR
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block tracking-tight">
                AnimeForge • Votre imagination en 4K
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => setActiveView('home')}
              className={`px-3.5 py-2 text-sm font-medium rounded-lg transition-all ${
                activeView === 'home'
                  ? 'text-white bg-purple-900/40 border border-purple-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              Accueil
            </button>

            <button
              onClick={() => setActiveView('studio')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all ${
                activeView === 'studio'
                  ? 'text-purple-300 bg-purple-900/40 border border-purple-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              Studio 4K
            </button>

            <button
              onClick={() => setActiveView('catalog')}
              className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-all ${
                activeView === 'catalog'
                  ? 'text-amber-300 bg-amber-900/20 border border-amber-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              Abonnements
            </button>

            <button
              onClick={onOpenRightsModal}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-400 bg-emerald-950/30 border border-emerald-600/30 rounded-lg hover:bg-emerald-900/40 transition-all"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Vos Droits</span>
            </button>

            {/* SECRET RULE: Only mohamedmerysiber@gmail.com with Mohamed@744 has user.isAdmin === true */}
            {user?.isAdmin && (
              <button
                onClick={() => setActiveView('admin')}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-sm font-bold rounded-lg transition-all ${
                  activeView === 'admin'
                    ? 'text-amber-200 bg-amber-600/30 border border-amber-400 glow-gold'
                    : 'text-amber-300 bg-amber-950/50 border border-amber-500/50 hover:bg-amber-900/60'
                }`}
              >
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                <span>Admin Privé</span>
              </button>
            )}
          </nav>

          {/* Right Action Tools: Currency Switcher & Auth */}
          <div className="flex items-center gap-3">
            
            {/* Currency Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900/80 border border-slate-700/60 text-xs font-semibold text-slate-200 hover:border-purple-500/60 transition-colors"
                title="Convertisseur de devises mondial"
              >
                <Globe className="w-3.5 h-3.5 text-purple-400" />
                <span>{selectedCurrency}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {currencyDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-56 rounded-xl bg-[#0d1222] border border-purple-500/30 shadow-2xl py-2 z-50 text-xs"
                  onClick={() => setCurrencyDropdownOpen(false)}
                >
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    Devise d'affichage & Conversion
                  </div>
                  {CURRENCY_CODES.map((cCode) => {
                    const c = CURRENCIES[cCode];
                    const isSelected = selectedCurrency === cCode;
                    return (
                      <button
                        key={cCode}
                        onClick={() => setSelectedCurrency(cCode)}
                        className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-purple-900/30 transition-colors ${
                          isSelected ? 'text-amber-400 font-bold bg-purple-950/40' : 'text-slate-300'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span className="font-mono-code font-bold w-10">{c.code}</span>
                          <span className="truncate max-w-[110px]">{c.name}</span>
                        </span>
                        <span className="text-slate-400 font-mono-code">{c.symbol}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* User Session or Login Button */}
            {user ? (
              <div className="flex items-center gap-2">
                <div 
                  onClick={() => user.isAdmin ? setActiveView('admin') : setActiveView('studio')}
                  className="hidden sm:flex flex-col text-right cursor-pointer"
                >
                  <span className="text-xs font-bold text-white truncate max-w-[120px]">
                    {user.name}
                  </span>
                  <span className="text-[10px] text-amber-400 font-medium">
                    {user.isAdmin 
                      ? 'Fondateur Maître (Illimité)' 
                      : user.planId === 'free' 
                      ? `${user.credits} essai${user.credits > 1 ? 's' : ''} restant${user.credits > 1 ? 's' : ''}`
                      : 'Membre VIP Actif'}
                  </span>
                </div>

                <button
                  onClick={logout}
                  className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                  title="Déconnexion"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="hidden sm:inline-flex px-3.5 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg border border-white/10 transition-all"
                >
                  Connexion
                </button>
                <button
                  onClick={() => onOpenAuth('signup')}
                  className="px-3.5 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 rounded-lg shadow-md shadow-amber-500/20 transition-all transform hover:-translate-y-0.5"
                >
                  3 Essais Gratuits
                </button>
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-300 hover:text-white focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-purple-900/40 py-4 space-y-2 bg-[#090d1b]">
            <button
              onClick={() => {
                setActiveView('home');
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-4 py-2.5 text-sm font-medium text-slate-200 hover:bg-purple-950/40 rounded-lg"
            >
              Accueil
            </button>
            <button
              onClick={() => {
                setActiveView('studio');
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-4 py-2.5 text-sm font-medium text-purple-300 hover:bg-purple-950/40 rounded-lg flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              Studio de Création 4K
            </button>
            <button
              onClick={() => {
                setActiveView('catalog');
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-4 py-2.5 text-sm font-medium text-amber-300 hover:bg-purple-950/40 rounded-lg flex items-center gap-2"
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              Catalogue des Abonnements
            </button>
            <button
              onClick={() => {
                onOpenRightsModal();
                setMobileMenuOpen(false);
              }}
              className="w-full text-left px-4 py-2.5 text-sm font-medium text-emerald-400 hover:bg-purple-950/40 rounded-lg flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              100% Vos Droits d'Auteur
            </button>
            {user?.isAdmin && (
              <button
                onClick={() => {
                  setActiveView('admin');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-4 py-2.5 text-sm font-bold text-amber-300 bg-amber-950/60 rounded-lg flex items-center gap-2"
              >
                <Crown className="w-4 h-4 text-amber-400" />
                Tableau de Bord Administrateur
              </button>
            )}
            {!user && (
              <div className="pt-2 px-4 flex gap-2">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 text-center text-xs font-semibold bg-white/10 rounded-lg text-white"
                >
                  Connexion
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('signup');
                    setMobileMenuOpen(false);
                  }}
                  className="flex-1 py-2 text-center text-xs font-bold bg-amber-400 text-black rounded-lg"
                >
                  3 Essais Gratuits
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
