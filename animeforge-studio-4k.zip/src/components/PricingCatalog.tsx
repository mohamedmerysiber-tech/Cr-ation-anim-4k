import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { PlanConfig } from '../types';
import { CURRENCIES, CURRENCY_CODES, convertFromXOF } from '../services/currency';
import { PaymentModal } from './PaymentModal';
import { 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Zap, 
  Crown, 
  CreditCard, 
  Clock, 
  Layers, 
  Globe,
  Tv,
  Film
} from 'lucide-react';

interface PricingCatalogProps {
  onOpenAuth: () => void;
}

export const PricingCatalog: React.FC<PricingCatalogProps> = ({ onOpenAuth }) => {
  const { 
    user, 
    adminSettings, 
    selectedCurrency, 
    setSelectedCurrency, 
    currentPlan, 
    setActiveView 
  } = useAuth();
  
  const [selectedPlanForPayment, setSelectedPlanForPayment] = useState<PlanConfig | null>(null);

  const handleSelectPlan = (plan: PlanConfig) => {
    if (!user) {
      onOpenAuth();
      return;
    }
    setSelectedPlanForPayment(plan);
  };

  return (
    <div className="py-12 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
          <Crown className="w-3.5 h-3.5" />
          <span>Grille Tarifaire Officielle • Validation Immédiate en Temps Réel</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-black text-white font-cinzel">
          Choisissez la puissance de votre{' '}
          <span className="bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 bg-clip-text text-transparent">
            Studio d'Animation
          </span>
        </h2>

        <p className="text-sm sm:text-base text-slate-300">
          Chaque nouvel inscrit bénéficie de <strong className="text-white">3 crédits d'essai gratuits</strong> avec filigrane Kamui Studio. 
          Passez à un pack officiel pour faire disparaître le logo, débloquer le rendu 4K et bénéficier des durées bonus incluses.
        </p>

        {/* Currency Switcher Bar */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 mr-2">
            <Globe className="w-3.5 h-3.5 text-purple-400" />
            <span>Devise d'affichage :</span>
          </span>
          {CURRENCY_CODES.map((cCode) => {
            const meta = CURRENCIES[cCode];
            const isSelected = selectedCurrency === cCode;
            return (
              <button
                key={cCode}
                onClick={() => setSelectedCurrency(cCode)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'bg-slate-900/80 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                {meta.code} ({meta.symbol})
              </button>
            );
          })}
        </div>
      </div>

      {/* Free Trial Banner */}
      <div className="mb-12 p-6 rounded-3xl bg-gradient-to-r from-purple-950/50 via-slate-900/60 to-purple-950/50 border border-purple-500/30 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2">
            <span className="px-2.5 py-0.5 text-[11px] font-extrabold uppercase rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Essai Gratuit
            </span>
            <span className="text-sm font-semibold text-white">3 Essais de Création Inclus</span>
          </div>
          <p className="text-xs text-slate-300 max-w-xl">
            Permet de tester la génération vidéo avec le filigrane "Kamui Studio" sur l'image. Dès souscription à un pack, le filigrane disparaît totalement et vos œuvres vous appartiennent à 100%.
          </p>
        </div>

        <button
          onClick={() => (user ? setActiveView('studio') : onOpenAuth())}
          className="px-6 py-3 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all flex items-center gap-2 shrink-0"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{user ? 'Ouvrir mon Studio' : 'Démarrer mes 3 Essais'}</span>
        </button>
      </div>

      {/* 8 Official Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {adminSettings.plans.map((plan) => {
          const { formatted } = convertFromXOF(plan.priceXOF, selectedCurrency);
          const isUserCurrentPlan = user?.planId === plan.id;
          const isUltime = plan.id === 'ultime';
          const isMultiMonth = plan.durationMonths > 1;

          return (
            <div
              key={plan.id}
              className={`relative rounded-3xl p-6 transition-all duration-300 flex flex-col justify-between ${
                isUltime
                  ? 'bg-gradient-to-b from-amber-950/50 via-[#10101e] to-black border-2 border-amber-400/70 shadow-2xl shadow-amber-900/30'
                  : plan.popular
                  ? 'bg-gradient-to-b from-purple-950/50 via-[#0e1224] to-black border-2 border-purple-500/60 shadow-xl shadow-purple-900/30'
                  : 'bg-glass-card border border-white/10 hover:border-slate-700'
              }`}
            >
              {/* Special Badge */}
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md">
                  {plan.badge}
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-black text-white font-cinzel">
                    {plan.name}
                  </h3>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                    plan.resolution === '4K Ultra' 
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40' 
                      : 'bg-purple-400/20 text-purple-300 border border-purple-400/40'
                  }`}>
                    {plan.resolution}
                  </span>
                </div>

                {/* Price Display */}
                <div className="mb-4">
                  <div className="text-2xl sm:text-3xl font-extrabold text-white font-cinzel">
                    {formatted}
                  </div>
                  <div className="text-xs text-amber-300/90 font-medium flex items-center gap-1.5 mt-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>{plan.durationLabel}</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-slate-300 mb-4">
                  <span className="text-slate-400">Durée par projet :</span>{' '}
                  <strong className="text-white font-semibold">{plan.maxVideoDuration}</strong>
                </div>

                {/* Features List */}
                <ul className="space-y-2.5 mb-6 text-xs text-slate-300">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div>
                <button
                  onClick={() => handleSelectPlan(plan)}
                  disabled={isUserCurrentPlan}
                  className={`w-full py-3 px-4 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center gap-2 ${
                    isUserCurrentPlan
                      ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 cursor-default'
                      : isUltime
                      ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 text-slate-950 hover:brightness-110 shadow-lg shadow-amber-500/20'
                      : plan.popular
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:brightness-110 shadow-lg shadow-purple-600/30'
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                  }`}
                >
                  {isUserCurrentPlan ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>Formule Actuelle</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      <span>Choisir ce Pack</span>
                    </>
                  )}
                </button>

                <p className="text-[10px] text-slate-400 text-center mt-2">
                  Validation automatique par Mobile Money / Carte / USDT
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Universal Currency Converter Widget */}
      <div className="mt-16 p-6 sm:p-8 rounded-3xl bg-glass-card border border-purple-500/30 space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-2">
              <Globe className="w-3.5 h-3.5" />
              <span>Moteur Multi-Devises Intelligent & Géolocalisation</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white font-cinzel">
              Convertisseur Universel de Devises en Temps Réel
            </h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Règle Zone FCFA fixe sans frais de change. Conversion automatique en Dollars ($ USD) pour l'Amérique du Nord, en Euros (€ EUR) pour l'Europe, en Yens (¥ JPY) pour le Japon/Asie et monnaies locales d'Afrique.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Devise active :</span>
            <span className="px-3 py-1.5 rounded-xl bg-purple-950 border border-purple-500/40 text-amber-300 font-bold font-mono-code text-xs">
              {selectedCurrency} ({CURRENCIES[selectedCurrency].symbol})
            </span>
          </div>
        </div>

        {/* Live Multi-Currency Conversion Matrix for Key Amounts */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 pt-2">
          {CURRENCY_CODES.map((code) => {
            const meta = CURRENCIES[code];
            const testAmount = 500000; // Pack Ultime
            const converted = convertFromXOF(testAmount, code);
            const isCurrent = selectedCurrency === code;

            return (
              <button
                key={code}
                onClick={() => setSelectedCurrency(code)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  isCurrent
                    ? 'bg-purple-950/70 border-amber-400 shadow-md shadow-purple-900/40 ring-1 ring-amber-400'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono-code font-bold text-xs text-white">{code}</span>
                  <span className="text-[10px] text-amber-300">{meta.symbol}</span>
                </div>
                <div className="text-[11px] font-bold text-amber-400 truncate">
                  {converted.formatted}
                </div>
                <span className="text-[9px] text-slate-400 block truncate mt-0.5">
                  Équiv. 500k FCFA
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Complete Tier Comparison Matrix */}
      <div className="mt-16 p-6 sm:p-8 rounded-3xl bg-glass-card border border-white/10 space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h3 className="text-xl sm:text-3xl font-black text-white font-cinzel">
            Tableau Comparatif des Durées & Privilèges
          </h3>
          <p className="text-xs text-slate-300">
            Comprenez en un coup d'œil les durées bonus, la résolution 4K et la suppression du filigrane Kamui Studio.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 font-mono-code text-[11px]">
              <tr>
                <th className="py-3 px-4">Formule</th>
                <th className="py-3 px-4">Durée de Validité</th>
                <th className="py-3 px-4">Durée Vidéo par Projet</th>
                <th className="py-3 px-4">Filigrane "Kamui Studio"</th>
                <th className="py-3 px-4">Qualité de Rendu</th>
                <th className="py-3 px-4">Bonus Spécial</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr className="hover:bg-white/5">
                <td className="py-3.5 px-4 font-bold text-white">Essai Gratuit</td>
                <td className="py-3.5 px-4 text-slate-400">3 Crédits</td>
                <td className="py-3.5 px-4 text-slate-300">15 secondes</td>
                <td className="py-3.5 px-4 text-amber-400 font-bold">Visible sur vidéo</td>
                <td className="py-3.5 px-4 text-slate-400">HD 1080p</td>
                <td className="py-3.5 px-4 text-slate-400">Aucune CB requise</td>
              </tr>
              <tr className="hover:bg-white/5">
                <td className="py-3.5 px-4 font-bold text-white">Packs Découverte à Avancé</td>
                <td className="py-3.5 px-4 text-slate-300">1 Mois Simple</td>
                <td className="py-3.5 px-4 text-slate-200">1s à 3 heures</td>
                <td className="py-3.5 px-4 text-emerald-400 font-bold">TOTALEMENT RETIRÉ</td>
                <td className="py-3.5 px-4 text-purple-300 font-bold">4K Cinéma</td>
                <td className="py-3.5 px-4 text-slate-300">Mode Privé débloqué</td>
              </tr>
              <tr className="hover:bg-purple-950/20 bg-purple-950/10">
                <td className="py-3.5 px-4 font-bold text-purple-300">Pack Pro (100k) & Expert (200k)</td>
                <td className="py-3.5 px-4 text-amber-300 font-black">3 MOIS D'UTILISATION INCLUS</td>
                <td className="py-3.5 px-4 text-white font-bold">5h à 10 heures à la minute près</td>
                <td className="py-3.5 px-4 text-emerald-400 font-bold">TOTALEMENT RETIRÉ</td>
                <td className="py-3.5 px-4 text-amber-400 font-bold">4K Ultra HD 60fps</td>
                <td className="py-3.5 px-4 text-purple-200">Rendu accéléré prioritaire</td>
              </tr>
              <tr className="hover:bg-amber-950/20 bg-amber-950/10 border-l-2 border-amber-400">
                <td className="py-3.5 px-4 font-black text-amber-300">Pack Studio Ultime (500k)</td>
                <td className="py-3.5 px-4 text-amber-300 font-black">4 MOIS AVEC RECHARGEMENT AUTO SANS REPAYER</td>
                <td className="py-3.5 px-4 text-white font-bold">Illimité (10h+)</td>
                <td className="py-3.5 px-4 text-emerald-400 font-bold">SANS LOGO / 100% PROPRIÉTAIRE</td>
                <td className="py-3.5 px-4 text-amber-400 font-black">4K Ultra Maximal 60fps</td>
                <td className="py-3.5 px-4 text-amber-300 font-bold">Grands Studios Tokyo & Équipe Illimitée</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      {selectedPlanForPayment && (
        <PaymentModal
          plan={selectedPlanForPayment}
          isOpen={!!selectedPlanForPayment}
          onClose={() => setSelectedPlanForPayment(null)}
          onSuccess={() => {
            setActiveView('studio');
          }}
        />
      )}

    </div>
  );
};
