import { CurrencyCode } from '../types';
export type { CurrencyCode };

export interface CurrencyMeta {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rateFromXOF: number; // 1 XOF = rate * foreign currency
  fixedZoneCFA?: boolean;
}

export const CURRENCY_CODES: CurrencyCode[] = ['XOF', 'XAF', 'USD', 'EUR', 'JPY', 'NGN', 'GHS', 'GBP', 'CAD'];

export const CURRENCIES: Record<CurrencyCode, CurrencyMeta> = {
  XOF: {
    code: 'XOF',
    symbol: 'FCFA',
    name: 'Franc CFA (UEMOA / CEMAC)',
    rateFromXOF: 1,
    fixedZoneCFA: true,
  },
  XAF: {
    code: 'XAF',
    symbol: 'FCFA',
    name: 'Franc CFA (CEMAC)',
    rateFromXOF: 1,
    fixedZoneCFA: true,
  },
  USD: {
    code: 'USD',
    symbol: '$',
    name: 'Dollar Américain',
    rateFromXOF: 1 / 610, // ~610 XOF per USD
  },
  EUR: {
    code: 'EUR',
    symbol: '€',
    name: 'Euro (Zone Euro)',
    rateFromXOF: 1 / 655.957, // Fixed official parity
  },
  JPY: {
    code: 'JPY',
    symbol: '¥',
    name: 'Yen Japonais',
    rateFromXOF: 1 / 4.1, // ~4.1 XOF per JPY
  },
  NGN: {
    code: 'NGN',
    symbol: '₦',
    name: 'Naira Nigérian',
    rateFromXOF: 2.38,
  },
  GHS: {
    code: 'GHS',
    symbol: 'GH₵',
    name: 'Cedi Ghanéen',
    rateFromXOF: 1 / 42,
  },
  GBP: {
    code: 'GBP',
    symbol: '£',
    name: 'Livre Sterling',
    rateFromXOF: 1 / 780,
  },
  CAD: {
    code: 'CAD',
    symbol: 'CA$',
    name: 'Dollar Canadien',
    rateFromXOF: 1 / 445,
  },
};

export interface DetectedGeo {
  country: string;
  countryCode: string;
  continent: string;
  city: string;
  currency: CurrencyCode;
  dialCode: string;
}

export function detectUserGeo(): DetectedGeo {
  try {
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    const lang = navigator.language || '';

    // Zone Franc CFA check
    if (
      timeZone.includes('Abidjan') ||
      timeZone.includes('Dakar') ||
      timeZone.includes('Bamako') ||
      timeZone.includes('Ouagadougou') ||
      timeZone.includes('Niamey') ||
      timeZone.includes('Lome') ||
      timeZone.includes('Cotonou') ||
      timeZone.includes('Douala') ||
      timeZone.includes('Libreville') ||
      timeZone.includes('Brazzaville')
    ) {
      return {
        country: "Côte d'Ivoire",
        countryCode: 'CI',
        continent: "Afrique de l'Ouest",
        city: 'Abidjan',
        currency: 'XOF',
        dialCode: '+225',
      };
    }

    if (timeZone.includes('Paris') || lang.startsWith('fr-FR')) {
      return {
        country: 'France',
        countryCode: 'FR',
        continent: 'Europe',
        city: 'Paris',
        currency: 'EUR',
        dialCode: '+33',
      };
    }

    if (timeZone.includes('Tokyo') || lang.startsWith('ja')) {
      return {
        country: 'Japon',
        countryCode: 'JP',
        continent: 'Asie',
        city: 'Tokyo',
        currency: 'JPY',
        dialCode: '+81',
      };
    }

    if (timeZone.includes('America') || lang.startsWith('en-US')) {
      return {
        country: 'États-Unis',
        countryCode: 'US',
        continent: 'Amérique du Nord',
        city: 'New York',
        currency: 'USD',
        dialCode: '+1',
      };
    }

    if (timeZone.includes('Lagos')) {
      return {
        country: 'Nigeria',
        countryCode: 'NG',
        continent: "Afrique de l'Ouest",
        city: 'Lagos',
        currency: 'NGN',
        dialCode: '+234',
      };
    }

    if (timeZone.includes('London')) {
      return {
        country: 'Royaume-Uni',
        countryCode: 'GB',
        continent: 'Europe',
        city: 'Londres',
        currency: 'GBP',
        dialCode: '+44',
      };
    }
  } catch (e) {
    // fallback
  }

  // Default to West Africa (Zone Franc CFA)
  return {
    country: "Côte d'Ivoire",
    countryCode: 'CI',
    continent: "Afrique de l'Ouest",
    city: 'Abidjan',
    currency: 'XOF',
    dialCode: '+225',
  };
}

export function convertFromXOF(amountXOF: number, targetCurrency: CurrencyCode): { amount: number; formatted: string } {
  const meta = CURRENCIES[targetCurrency] || CURRENCIES.XOF;
  
  if (meta.fixedZoneCFA || targetCurrency === 'XOF' || targetCurrency === 'XAF') {
    return {
      amount: amountXOF,
      formatted: `${new Intl.NumberFormat('fr-FR').format(amountXOF)} FCFA`,
    };
  }

  const converted = amountXOF * meta.rateFromXOF;

  if (targetCurrency === 'JPY') {
    const rounded = Math.round(converted);
    return {
      amount: rounded,
      formatted: `¥ ${new Intl.NumberFormat('ja-JP').format(rounded)}`,
    };
  }

  if (targetCurrency === 'USD') {
    const fixed = Math.round(converted * 100) / 100;
    return {
      amount: fixed,
      formatted: `$ ${new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(fixed)}`,
    };
  }

  if (targetCurrency === 'EUR') {
    const fixed = Math.round(converted * 100) / 100;
    return {
      amount: fixed,
      formatted: `${new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(fixed)} €`,
    };
  }

  if (targetCurrency === 'GBP') {
    const fixed = Math.round(converted * 100) / 100;
    return {
      amount: fixed,
      formatted: `£ ${new Intl.NumberFormat('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(fixed)}`,
    };
  }

  if (targetCurrency === 'CAD') {
    const fixed = Math.round(converted * 100) / 100;
    return {
      amount: fixed,
      formatted: `CA$ ${new Intl.NumberFormat('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(fixed)}`,
    };
  }

  if (targetCurrency === 'NGN') {
    const rounded = Math.round(converted);
    return {
      amount: rounded,
      formatted: `₦ ${new Intl.NumberFormat('en-NG').format(rounded)}`,
    };
  }

  return {
    amount: Math.round(converted),
    formatted: `${meta.symbol} ${new Intl.NumberFormat('fr-FR').format(Math.round(converted))}`,
  };
}
