/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CreationStudio } from './components/CreationStudio';
import { PricingCatalog } from './components/PricingCatalog';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { RightsModal } from './components/RightsModal';
import { 
  Sparkles, 
  Film, 
  ShieldCheck, 
  Tv, 
  Palette, 
  Globe, 
  Award, 
  CheckCircle2, 
  ArrowRight,
  Flame,
  Zap,
  Play
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeView, setActiveView, user } = useAuth();
  
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalInitialMode, setAuthModalInitialMode] = useState<'login' | 'signup'>('login');
  const [rightsModalOpen, setRightsModalOpen] = useState(false);

  const openAuth = (mode: 'login' | 'signup' = 'login') => {
    setAuthModalInitialMode(mode);
    setAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#05070f] text-slate-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        onOpenAuth={openAuth}
        onOpenRightsModal={() => setRightsModalOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        
        {/* VIEW 1: HOME */}
        {activeView === 'home' && (
          <div>
            <Hero
              onStartFreeTrial={() => (user ? setActiveView('studio') : openAuth('signup'))}
              onExplorePlans={() => setActiveView('catalog')}
              onOpenRightsModal={() => setRightsModalOpen(true)}
            />

            {/* Visual Showcase Section */}
            <section className="py-16 border-t border-purple-900/30 bg-[#070a18]/60 relative">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                <div className="text-center max-w-2xl mx-auto space-y-3">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold">
                    <Palette className="w-3.5 h-3.5 text-amber-400" />
                    <span>L'Excellence des 15 Plus Grands Studios Mondiaux</span>
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-cinzel">
                    Des signatures visuelles légendaires
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300">
                    Notre algorithme analyse et réplique les cadrages, éclairages volumétriques et dynamiques de combat des maîtres de l'animation.
                  </p>
                </div>

                {/* 3 Featured Anime Visual Previews */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="group rounded-3xl overflow-hidden bg-glass-card border border-white/10 hover:border-purple-500/50 transition-all p-4 space-y-3">
                    <div className="aspect-video rounded-2xl bg-gradient-to-br from-indigo-950 via-purple-900/50 to-black relative overflow-hidden flex items-center justify-center border border-slate-800">
                      <span className="text-5xl group-hover:scale-110 transition-transform">⚔️</span>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <span className="absolute bottom-3 left-3 text-xs font-bold text-white font-cinzel">
                        Tokyo Action (Shōnen)
                      </span>
                      <span className="absolute top-3 right-3 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-black">
                        4K 60FPS
                      </span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-white">Chorégraphies au sabre dynamiques</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Mouvements de caméra à 360°, auras électriques et impacts cinématiques inspirés des studios Mappa et Ufotable.
                      </p>
                    </div>
                  </div>

                  <div className="group rounded-3xl overflow-hidden bg-glass-card border border-white/10 hover:border-rose-500/50 transition-all p-4 space-y-3">
                    <div className="aspect-video rounded-2xl bg-gradient-to-br from-rose-950 via-pink-900/50 to-black relative overflow-hidden flex items-center justify-center border border-slate-800">
                      <span className="text-5xl group-hover:scale-110 transition-transform">🌸</span>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <span className="absolute bottom-3 left-3 text-xs font-bold text-white font-cinzel">
                        Kyoto Romance & Poésie
                      </span>
                      <span className="absolute top-3 right-3 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-400 text-black">
                        HDR Douceur
                      </span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-white">Lumière volumétrique & Émotions</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Reflets de crépuscule sur l'eau, pétales de cerisier au vent et micro-expressions faciales bouleversantes.
                      </p>
                    </div>
                  </div>

                  <div className="group rounded-3xl overflow-hidden bg-glass-card border border-white/10 hover:border-cyan-500/50 transition-all p-4 space-y-3">
                    <div className="aspect-video rounded-2xl bg-gradient-to-br from-cyan-950 via-teal-900/50 to-black relative overflow-hidden flex items-center justify-center border border-slate-800">
                      <span className="text-5xl group-hover:scale-110 transition-transform">⚡</span>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <span className="absolute bottom-3 left-3 text-xs font-bold text-white font-cinzel">
                        Shibuya Neon & Donghua 3D
                      </span>
                      <span className="absolute top-3 right-3 px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-400 text-black">
                        3D Épique
                      </span>
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-white">Cyberpunk & Mythologie Moderne</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Gratte-ciels néon sous la pluie, créatures célestes en textures soyeuses et effets holographiques 4K.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Big Banner Call to Action */}
                <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-amber-950/60 border border-purple-500/40 text-center space-y-6">
                  <h3 className="text-2xl sm:text-4xl font-extrabold text-white font-cinzel">
                    Prêt à donner vie à votre premier chef-d'œuvre ?
                  </h3>
                  <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto">
                    Activez vos 3 essais gratuits en 10 secondes. Créez des scènes avec dialogues doublés, synchronisation labiale et exportez en 4K.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-4">
                    <button
                      onClick={() => (user ? setActiveView('studio') : openAuth('signup'))}
                      className="px-8 py-4 rounded-xl text-sm font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-xl shadow-amber-500/25 transition-all flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4 text-slate-950" />
                      <span>{user ? 'Accéder au Studio 4K' : 'Démarrer mes 3 Essais Gratuits'}</span>
                    </button>
                    <button
                      onClick={() => setActiveView('catalog')}
                      className="px-6 py-4 rounded-xl text-sm font-semibold text-white bg-slate-900 border border-slate-700 hover:bg-slate-800 transition-all"
                    >
                      Voir les 8 Abonnements
                    </button>
                  </div>
                </div>

              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: STUDIO DE CRÉATION */}
        {activeView === 'studio' && <CreationStudio />}

        {/* VIEW 3: CATALOGUE DES ABONNEMENTS */}
        {activeView === 'catalog' && <PricingCatalog onOpenAuth={() => openAuth('signup')} />}

        {/* VIEW 4: ADMIN DASHBOARD (Accessible ONLY to mohamedmerysiber@gmail.com) */}
        {activeView === 'admin' && <AdminDashboard />}

      </main>

      {/* Footer */}
      <Footer
        onOpenRightsModal={() => setRightsModalOpen(true)}
        onOpenAuth={() => openAuth('signup')}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalInitialMode}
      />

      {/* 100% Rights & Copyright Modal */}
      <RightsModal
        isOpen={rightsModalOpen}
        onClose={() => setRightsModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
