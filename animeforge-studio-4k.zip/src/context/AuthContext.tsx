import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, PlanConfig, Transaction, AdminSettings, CurrencyCode } from '../types';
import { detectUserGeo, convertFromXOF } from '../services/currency';

export const INITIAL_PLANS: PlanConfig[] = [
  {
    id: 'decouverte',
    name: 'Pack Découverte',
    priceXOF: 5000,
    durationMonths: 1,
    durationLabel: '1 mois',
    maxVideoDuration: '2 secondes',
    hasWatermark: false,
    resolution: 'HD',
    highlightColor: 'from-blue-600 to-cyan-500',
    features: [
      'Clips courts de 1 à 2 secondes',
      'Sans filigrane / Sans logo Kamui',
      'Rendu HD fluide (1080p)',
      'Accès aux 12 styles de base',
      'Validité 1 mois d’accès',
    ],
  },
  {
    id: 'mini',
    name: 'Pack Mini',
    priceXOF: 10000,
    durationMonths: 1,
    durationLabel: '1 mois',
    maxVideoDuration: '15 secondes',
    hasWatermark: false,
    resolution: '4K',
    highlightColor: 'from-cyan-600 to-teal-500',
    features: [
      'Courtes scènes animées (15 sec)',
      'Qualité HD / 4K standard',
      'Sans filigrane Kamui Studio',
      'Synchronisation labiale de base',
      'Validité 1 mois',
    ],
  },
  {
    id: 'debutant',
    name: 'Pack Débutant',
    priceXOF: 45000,
    durationMonths: 1,
    durationLabel: '1 mois',
    maxVideoDuration: '1 heure',
    hasWatermark: false,
    resolution: '4K',
    highlightColor: 'from-emerald-600 to-green-500',
    features: [
      'Animés complets jusqu’à 1 heure',
      'Importation de visages & photos de base',
      'Mode Privé : retouche personnages & décors',
      'Rendu 4K cinématique',
      'Validité 1 mois d’accès',
    ],
  },
  {
    id: 'standard',
    name: 'Pack Standard',
    priceXOF: 50000,
    durationMonths: 1,
    durationLabel: '1 mois',
    maxVideoDuration: '2 heures',
    hasWatermark: false,
    resolution: '4K',
    highlightColor: 'from-amber-600 to-yellow-500',
    features: [
      'Animés jusqu’à 2 heures par projet',
      'Choix avancé des 6 ambiances cinématographiques',
      'Doublages et clonage vocal IA réaliste',
      'Accès aux 15 grands studios mondiaux',
      'Validité 1 mois',
    ],
  },
  {
    id: 'avance',
    name: 'Pack Avancé',
    priceXOF: 55000,
    durationMonths: 1,
    durationLabel: '1 mois',
    maxVideoDuration: '3 heures',
    hasWatermark: false,
    resolution: '4K',
    highlightColor: 'from-orange-600 to-rose-500',
    features: [
      'Animés jusqu’à 3 heures',
      'Mouvements humains ultra-réalistes',
      'Clonage de chorégraphies par vidéo',
      'Génération d’OST et musiques chantées',
      'Validité 1 mois',
    ],
  },
  {
    id: 'pro',
    name: 'Pack Pro',
    priceXOF: 100000,
    durationMonths: 3,
    durationLabel: '3 mois d’utilisation inclus',
    maxVideoDuration: '5 heures',
    hasWatermark: false,
    resolution: '4K',
    popular: true,
    badge: 'Formule Professionnelle (3 Mois)',
    highlightColor: 'from-purple-600 to-indigo-600',
    features: [
      'Studio de production virtuel personnalisé',
      'Validité 3 MOIS inclus (sans réabonnement mensuel)',
      'Rendu prioritaire sur serveurs 4K accélérés',
      'Formats TikTok / Reels / Publicités en 1 clic',
      'Messagerie collaborative illimitée en temps réel',
    ],
  },
  {
    id: 'expert',
    name: 'Pack Expert',
    priceXOF: 200000,
    durationMonths: 3,
    durationLabel: '3 mois d’utilisation inclus',
    maxVideoDuration: '10 heures',
    hasWatermark: false,
    resolution: '4K Ultra',
    badge: 'Réalisation Cinéma (3 Mois)',
    highlightColor: 'from-pink-600 to-purple-700',
    features: [
      'Outils de réalisation ultra-modernes',
      'Animés très longs de 5h à 10h réglés à la minute près',
      'Validité 3 MOIS inclus',
      'Casting étendu jusqu’à 100 000+ visages & décors',
      'Export multi-pistes vidéo 4K et audio Dolby',
    ],
  },
  {
    id: 'ultime',
    name: 'Pack Studio Ultime',
    priceXOF: 500000,
    durationMonths: 4,
    durationLabel: '4 mois avec rechargement auto sans repayer',
    maxVideoDuration: 'Illimité (10h+)',
    hasWatermark: false,
    resolution: '4K Ultra',
    popular: true,
    badge: 'Prestige Studios Japonais (4 Mois)',
    highlightColor: 'from-amber-400 via-orange-500 to-red-600',
    features: [
      'Fonctionnalités illimitées dignes des plus grands studios de Tokyo',
      'Validité 4 MOIS avec RECHARGEMENT AUTOMATIQUE sans repayer',
      'Reproduction fidèle de toutes les signatures visuelles de studios',
      'Rendu 4K maximal 60fps & synchronisation labiale chirurgicale',
      'Collaboration d’équipe illimitée (invitation sans limite)',
      '100% de vos droits d’auteur garantis & assistance VIP 24/7',
    ],
  },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-init-1',
    userId: 'u-101',
    userName: 'Koffi Jean-Luc',
    userEmail: 'koffi.jean@gmail.com',
    planId: 'ultime',
    planName: 'Pack Studio Ultime',
    amountXOF: 500000,
    currency: 'XOF',
    amountLocal: 500000,
    paymentMethod: 'WAVE',
    continent: "Afrique de l'Ouest",
    country: "Côte d'Ivoire",
    city: 'Abidjan',
    status: 'COMPLETED',
    timestamp: '2026-11-10 14:32:00',
    reference: 'WAV-CI-847291',
  },
  {
    id: 'tx-init-2',
    userId: 'u-102',
    userName: 'Alexandre Meyer',
    userEmail: 'alex.meyer@animestudio.fr',
    planId: 'expert',
    planName: 'Pack Expert',
    amountXOF: 200000,
    currency: 'EUR',
    amountLocal: 304.89,
    paymentMethod: 'CARD',
    continent: 'Europe',
    country: 'France',
    city: 'Paris',
    status: 'COMPLETED',
    timestamp: '2026-11-10 18:15:20',
    reference: 'STR-EUR-993821',
  },
  {
    id: 'tx-init-3',
    userId: 'u-103',
    userName: 'Fatou Diallo',
    userEmail: 'fatou.d@senegalmanga.sn',
    planId: 'pro',
    planName: 'Pack Pro',
    amountXOF: 100000,
    currency: 'XOF',
    amountLocal: 100000,
    paymentMethod: 'ORANGE_MONEY',
    continent: "Afrique de l'Ouest",
    country: 'Sénégal',
    city: 'Dakar',
    status: 'COMPLETED',
    timestamp: '2026-11-11 09:44:11',
    reference: 'OM-SN-448201',
  },
  {
    id: 'tx-init-4',
    userId: 'u-104',
    userName: 'Takeshi Tanaka',
    userEmail: 't.tanaka@shibuya-art.jp',
    planId: 'ultime',
    planName: 'Pack Studio Ultime',
    amountXOF: 500000,
    currency: 'JPY',
    amountLocal: 121950,
    paymentMethod: 'USDT',
    continent: 'Asie',
    country: 'Japon',
    city: 'Tokyo',
    status: 'COMPLETED',
    timestamp: '2026-11-11 12:05:43',
    reference: 'USDT-TRC20-0x8b32..4a',
  },
  {
    id: 'tx-init-5',
    userId: 'u-105',
    userName: 'Marcus Vance',
    userEmail: 'm.vance@hollywood-anim.com',
    planId: 'expert',
    planName: 'Pack Expert',
    amountXOF: 200000,
    currency: 'USD',
    amountLocal: 327.86,
    paymentMethod: 'CARD',
    continent: 'Amérique du Nord',
    country: 'États-Unis',
    city: 'Los Angeles',
    status: 'COMPLETED',
    timestamp: '2026-11-11 15:22:19',
    reference: 'STR-US-102934',
  },
];

const INITIAL_ADMIN_SETTINGS: AdminSettings = {
  registrationFeeXOF: 0,
  plans: INITIAL_PLANS,
  mobileMoneyAccounts: {
    wave: '+225 07 88 44 12 30',
    orangeMoney: '+225 07 48 90 22 15',
    mtnMoMo: '+225 05 64 33 11 09',
    moov: '+225 01 22 33 44 55',
  },
  cryptoAccounts: {
    usdtTrc20: 'TQ9z7kL7mB3y5xJ9wR2vA4cD8eF1gH3jK5',
    usdtErc20: '0x71C3b7e780D3D1c518F45a3Dbb7A84D5EbA4940b',
  },
  bankAccount: {
    bankName: 'Société Générale / BOA International',
    iban: 'CI93 CI03 4010 0100 1234 5678 9012',
    bic: 'BGFICIABXXX',
  },
  cityAdjustments: {
    Abidjan: 0,
    Dakar: 0,
    Paris: 0,
    'New York': 0,
    Tokyo: 0,
  },
  systemAnnouncements: [
    'Mise à jour v4.8 déployée : Rendu cinématique 4K 60fps & moteur de synchronisation labiale activés.',
    'Sécurité renforcée : 0% de frais sur tous les transferts administrateur.',
  ],
};

interface AuthContextType {
  user: User | null;
  selectedCurrency: CurrencyCode;
  setSelectedCurrency: (c: CurrencyCode) => void;
  adminSettings: AdminSettings;
  transactions: Transaction[];
  currentPlan: PlanConfig | null;
  activeView: 'home' | 'studio' | 'catalog' | 'admin';
  setActiveView: (view: 'home' | 'studio' | 'catalog' | 'admin') => void;
  login: (email: string, pass: string) => { success: boolean; message: string; isAdmin: boolean };
  signup: (userData: {
    name: string;
    email: string;
    pass: string;
    phone: string;
    country: string;
    countryCode: string;
  }) => { success: boolean; message: string; isAdmin: boolean };
  logout: () => void;
  consumeCredit: () => boolean;
  processSubscription: (
    planId: string,
    paymentMethod: 'WAVE' | 'ORANGE_MONEY' | 'MTN_MOMO' | 'MOOV' | 'CARD' | 'USDT',
    payerDetails?: { phone?: string; cardLast4?: string; txHash?: string }
  ) => Promise<{ success: boolean; transaction: Transaction }>;
  // Admin Operations (Exclusive to mohamedmerysiber@gmail.com)
  updatePlanPrice: (planId: string, newPriceXOF: number, newMonths?: number) => void;
  updateRegistrationFee: (fee: number) => void;
  updateAdminAccounts: (accounts: Partial<AdminSettings>) => void;
  grantCreatorBonus: (targetEmail: string, bonusCredits: number, isVip: boolean) => boolean;
  deployPlatformUpdate: (versionNotes: string) => void;
  executeAdminTransfer: (
    amountXOF: number,
    targetAccount: string,
    targetCurrency: CurrencyCode
  ) => { success: boolean; message: string; tx: any };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('XOF');
  const [activeView, setActiveView] = useState<'home' | 'studio' | 'catalog' | 'admin'>('home');

  // Load User from LocalStorage or default
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('kamui_user_session');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });

  // Admin settings state
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(() => {
    try {
      const saved = localStorage.getItem('kamui_admin_settings');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_ADMIN_SETTINGS;
  });

  // Transactions state
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('kamui_transactions');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_TRANSACTIONS;
  });

  // Save to localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem('kamui_user_session', JSON.stringify(user));
    } else {
      localStorage.removeItem('kamui_user_session');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('kamui_admin_settings', JSON.stringify(adminSettings));
  }, [adminSettings]);

  useEffect(() => {
    localStorage.setItem('kamui_transactions', JSON.stringify(transactions));
  }, [transactions]);

  // Initial Geo Detection
  useEffect(() => {
    const geo = detectUserGeo();
    if (geo.currency) {
      setSelectedCurrency(geo.currency);
    }
  }, []);

  // Determine current active plan
  const currentPlan = user?.planId && user.planId !== 'free'
    ? adminSettings.plans.find((p) => p.id === user.planId) || null
    : null;

  // Login function with Anti-Hacking & Secret Admin Lock
  const login = (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();

    // STRICT OWNER CHECK: mohamedmerysiber@gmail.com + Mohamed@744
    if (cleanEmail === 'mohamedmerysiber@gmail.com' && cleanPass === 'Mohamed@744') {
      const adminUser: User = {
        id: 'usr-admin-mohamed',
        name: 'Mohamed Mery Siber (Propriétaire Fondateur)',
        email: 'mohamedmerysiber@gmail.com',
        phone: '+225 07 00 00 00 00',
        country: "Côte d'Ivoire",
        countryCode: 'CI',
        planId: 'ultime', // Free unlimited
        credits: 999999,
        isAdmin: true,
        isVip: true,
        createdAt: '2026-01-01',
      };
      setUser(adminUser);
      setActiveView('admin');
      return {
        success: true,
        message: 'Accès Maître Authentifié. Bienvenue dans votre Tableau de Bord Administrateur.',
        isAdmin: true,
      };
    }

    // Normal user check
    if (cleanEmail === 'mohamedmerysiber@gmail.com' && cleanPass !== 'Mohamed@744') {
      return {
        success: false,
        message: 'Mot de passe administrateur incorrect. Accès refusé par le système anti-intrusion.',
        isAdmin: false,
      };
    }

    // Standard simulated user authentication
    const normalUser: User = {
      id: `usr-${Date.now()}`,
      name: cleanEmail.split('@')[0],
      email: cleanEmail,
      phone: '+225 00 00 00 00',
      country: "Côte d'Ivoire",
      countryCode: 'CI',
      planId: 'free',
      credits: 3, // 3 essais gratuits
      isAdmin: false,
      isVip: false,
      createdAt: new Date().toISOString(),
    };
    setUser(normalUser);
    setActiveView('studio');
    return {
      success: true,
      message: 'Connexion réussie ! Vos 3 essais gratuits sont activés.',
      isAdmin: false,
    };
  };

  // Sign up function
  const signup = (userData: {
    name: string;
    email: string;
    pass: string;
    phone: string;
    country: string;
    countryCode: string;
  }) => {
    const cleanEmail = userData.email.trim().toLowerCase();
    const cleanPass = userData.pass.trim();

    // Check if Secret Admin signup
    if (cleanEmail === 'mohamedmerysiber@gmail.com' && cleanPass === 'Mohamed@744') {
      const adminUser: User = {
        id: 'usr-admin-mohamed',
        name: 'Mohamed Mery Siber (Propriétaire Fondateur)',
        email: 'mohamedmerysiber@gmail.com',
        phone: userData.phone || '+225 07 00 00 00 00',
        country: userData.country || "Côte d'Ivoire",
        countryCode: userData.countryCode || 'CI',
        planId: 'ultime',
        credits: 999999,
        isAdmin: true,
        isVip: true,
        createdAt: new Date().toISOString(),
      };
      setUser(adminUser);
      setActiveView('admin');
      return {
        success: true,
        message: 'Compte Propriétaire créé et validé. Redirection vers le Tableau de Bord Administrateur.',
        isAdmin: true,
      };
    }

    // Standard User Signup with 3 Free Trial credits
    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: userData.name,
      email: cleanEmail,
      phone: userData.phone,
      country: userData.country,
      countryCode: userData.countryCode,
      planId: 'free',
      credits: 3, // 3 crédits d'essai gratuits
      isAdmin: false,
      isVip: false,
      createdAt: new Date().toISOString(),
    };
    setUser(newUser);
    setActiveView('studio');
    return {
      success: true,
      message: 'Compte créé avec succès ! Vous bénéficiez de 3 crédits d’essai gratuits (filigrane Kamui).',
      isAdmin: false,
    };
  };

  const logout = () => {
    setUser(null);
    setActiveView('home');
  };

  const consumeCredit = (): boolean => {
    if (!user) return false;
    if (user.isAdmin || user.planId === 'ultime') return true; // unlimited
    if (user.credits <= 0) return false;

    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        credits: Math.max(0, prev.credits - 1),
      };
    });
    return true;
  };

  // Process Subscription Payment with Immediate Automatic Validation
  const processSubscription = async (
    planId: string,
    paymentMethod: 'WAVE' | 'ORANGE_MONEY' | 'MTN_MOMO' | 'MOOV' | 'CARD' | 'USDT',
    payerDetails?: { phone?: string; cardLast4?: string; txHash?: string }
  ): Promise<{ success: boolean; transaction: Transaction }> => {
    const plan = adminSettings.plans.find((p) => p.id === planId);
    if (!plan) throw new Error('Pack introuvable');

    const geo = detectUserGeo();
    const currency = selectedCurrency;
    const { amount: amountLocal } = convertFromXOF(plan.priceXOF, currency);

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      userId: user?.id || `anon-${Date.now()}`,
      userName: user?.name || 'Client Kamui',
      userEmail: user?.email || 'client@studio.com',
      planId: plan.id,
      planName: plan.name,
      amountXOF: plan.priceXOF,
      currency: currency,
      amountLocal: amountLocal,
      paymentMethod,
      continent: geo.continent,
      country: user?.country || geo.country,
      city: geo.city,
      status: 'COMPLETED',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      reference: `${paymentMethod}-${Date.now().toString().slice(-6)}`,
    };

    // Add to ledger
    setTransactions((prev) => [newTx, ...prev]);

    // Update user subscription state immediately
    if (user) {
      const expirationDate = new Date();
      expirationDate.setMonth(expirationDate.getMonth() + plan.durationMonths);

      setUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          planId: plan.id,
          planExpiresAt: expirationDate.toISOString(),
          isVip: true,
          credits: prev.credits + (plan.id === 'ultime' ? 9999 : 100),
        };
      });
    }

    return { success: true, transaction: newTx };
  };

  // ADMIN OPERATIONS (Only available to mohamedmerysiber@gmail.com)
  const updatePlanPrice = (planId: string, newPriceXOF: number, newMonths?: number) => {
    if (!user?.isAdmin) return;
    setAdminSettings((prev) => ({
      ...prev,
      plans: prev.plans.map((p) => {
        if (p.id === planId) {
          return {
            ...p,
            priceXOF: Math.max(100, newPriceXOF),
            durationMonths: newMonths !== undefined ? newMonths : p.durationMonths,
          };
        }
        return p;
      }),
    }));
  };

  const updateRegistrationFee = (fee: number) => {
    if (!user?.isAdmin) return;
    setAdminSettings((prev) => ({
      ...prev,
      registrationFeeXOF: Math.max(0, fee),
    }));
  };

  const updateAdminAccounts = (accounts: Partial<AdminSettings>) => {
    if (!user?.isAdmin) return;
    setAdminSettings((prev) => ({
      ...prev,
      ...accounts,
    }));
  };

  const grantCreatorBonus = (targetEmail: string, bonusCredits: number, isVip: boolean): boolean => {
    if (!user?.isAdmin) return false;
    // Broadcast notification or log
    setAdminSettings((prev) => ({
      ...prev,
      systemAnnouncements: [
        `Bonus Créateur : +${bonusCredits} crédits VIP octroyés à l'utilisateur [${targetEmail}]`,
        ...prev.systemAnnouncements,
      ],
    }));
    return true;
  };

  const deployPlatformUpdate = (versionNotes: string) => {
    if (!user?.isAdmin) return;
    setAdminSettings((prev) => ({
      ...prev,
      systemAnnouncements: [
        `[MISE À JOUR OFFICIELLE DÉPLOYÉE] ${versionNotes}`,
        ...prev.systemAnnouncements,
      ],
    }));
  };

  const executeAdminTransfer = (
    amountXOF: number,
    targetAccount: string,
    targetCurrency: CurrencyCode
  ) => {
    if (!user?.isAdmin) {
      return { success: false, message: 'Accès refusé', tx: null };
    }

    const { amount: localAmt, formatted } = convertFromXOF(amountXOF, targetCurrency);
    const tx = {
      id: `wdr-${Date.now()}`,
      amountXOF,
      localAmt,
      formatted,
      targetAccount,
      targetCurrency,
      feePercentage: 0, // 0% DE FRAIS
      status: 'CONFIRMED',
      timestamp: new Date().toISOString(),
    };

    return {
      success: true,
      message: `Virement instantané de ${formatted} (0% de frais) exécuté vers ${targetAccount}.`,
      tx,
    };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        selectedCurrency,
        setSelectedCurrency,
        adminSettings,
        transactions,
        currentPlan,
        activeView,
        setActiveView,
        login,
        signup,
        logout,
        consumeCredit,
        processSubscription,
        updatePlanPrice,
        updateRegistrationFee,
        updateAdminAccounts,
        grantCreatorBonus,
        deployPlatformUpdate,
        executeAdminTransfer,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
